_base_ = [
    # '../_base_/datasets/dotav1.py', '../_base_/schedules/schedule_1x.py',
    '../_base_/datasets/hrsc.py', '../_base_/schedules/schedule_1x.py',
    '../_base_/default_runtime.py'
]

angle_version = 'le90'
gpu_number = 8
# fp16 = dict(loss_scale='dynamic')
model = dict(
    type='OrientedRCNN',
    backbone=dict(
        # ---------------------------------------------------------------------------------
        # type='ResNet',
        # type='MyNet',
        type='Final_ResNet',
        depth=50,
        num_stages=4,
        out_indices=(0, 1, 2, 3),
        frozen_stages=1,
        norm_cfg=dict(type='SyncBN', requires_grad=True),
        norm_eval=True,
        style='pytorch',
        init_cfg=dict(type='Pretrained', checkpoint='./data/pretrained/resnet50.pth')),
        # ----------------------------------------------------------------------------------
        # type='LSKNet',
        # embed_dims=[64, 128, 320, 512],
        # drop_rate=0.1,
        # drop_path_rate=0.1,
        # depths=[2, 2, 4, 2],
        # init_cfg=dict(type='Pretrained', checkpoint="./data/pretrained/lsk_s_backbone.pth"),
        # norm_cfg=dict(type='SyncBN', requires_grad=True)),
    # -----------------------------------------------------------
    # neck=dict(
    #     # _delete_=True,
    #     type='NASFPN',
    #     in_channels=[256, 512, 1024, 2048],
    #     out_channels=256,
    #     num_outs=5,
    #     stack_times=7,
    #     start_level=1,
    #     norm_cfg=dict(type='SyncBN', requires_grad=True)),
    # -----------------------------------------------------------
    #     neck=dict(
    #         type='FPG',     # FPG - Neck   910.xMB,pth太大
    #         in_channels=[256, 512, 1024, 2048],
    #         out_channels=256,
    #         inter_channels=256,
    #         num_outs=5,
    #         stack_times=9,
    #         paths=['bu'] * 9,
    #         same_down_trans=None,
    #         same_up_trans=dict(
    #             type='conv',
    #             kernel_size=3,
    #             stride=2,
    #             padding=1,
    #             norm_cfg=dict(type='SyncBN', requires_grad=True),
    #             inplace=False,
    #             order=('act', 'conv', 'norm')),
    #         across_lateral_trans=dict(
    #             type='conv',
    #             kernel_size=1,
    #             norm_cfg=dict(type='SyncBN', requires_grad=True),
    #             inplace=False,
    #             order=('act', 'conv', 'norm')),
    #         across_down_trans=dict(
    #             type='interpolation_conv',
    #             mode='nearest',
    #             kernel_size=3,
    #             norm_cfg=dict(type='SyncBN', requires_grad=True),
    #             order=('act', 'conv', 'norm'),
    #             inplace=False),
    #         across_up_trans=None,
    #         across_skip_trans=dict(
    #             type='conv',
    #             kernel_size=1,
    #             norm_cfg=dict(type='SyncBN', requires_grad=True),
    #             inplace=False,
    #             order=('act', 'conv', 'norm')),
    #         output_trans=dict(
    #             type='last_conv',
    #             kernel_size=3,
    #             order=('act', 'conv', 'norm'),
    #             inplace=False),
    #         norm_cfg=dict(type='SyncBN', requires_grad=True),
    #         skip_inds=[(0, 1, 2, 3), (0, 1, 2), (0, 1), (0, ), ()]),
    # -----------------------------------------------------------
    # neck=[      # BFP
    #     dict(
    #         type='FPN',
    #         in_channels=[256, 512, 1024, 2048],  # resnet/res2net
    #         # in_channels=[64, 128, 320, 512],   # LSKNet
    #         out_channels=256,
    #         num_outs=5),
    #     dict(
    #         type='BFP',
    #         in_channels=256,
    #         num_levels=5,
    #         refine_level=1,
    #         refine_type='non_local')
    # ],
    # -----------------------------------------------------------
    # neck=[
    #     dict(
    #         type='FPN',
    #         in_channels=[256, 512, 1024, 2048],  # resnet/res2net
    #         # in_channels=[64, 128, 320, 512],   # LSKNet
    #         out_channels=256,
    #         num_outs=5),
    #     dict(type='DyHead', in_channels=256, out_channels=256, num_blocks=6)
    # ],
    # -----------------------------------------------------------
    # data_preprocessor=dict(pad_size_divisor=128),   # 不需要 其他网络中继承的配置
    # neck=dict(
    #     type='NASFPN',
    #     in_channels=[256, 512, 1024, 2048],
    #     out_channels=256,
    #     num_outs=5,
    #     stack_times=7,
    #     start_level=1,
    #     # norm_cfg=dict(type='BN', requires_grad=True)),
    #     norm_cfg=dict(type='SyncBN', requires_grad=True)),
    # -----------------------------------------------------------
    neck=dict(      # 原始neck
        # -------------------------------------------------------
        # type='PAFPN',  # 换成PAFPN
        # =======================================================
        # type='FPN',     # 只修改backbone的时候使用这个neck
        # type='MyFPN',   # 使用自己修改后的FPN  >>> MyFPN
        # type='SSFPN',   # 使用自己修改后的FPN  >>> SSFPN
        type='Final_FPN',   # 使用自己修改后的FPN  >>> Final_FPN==FPN改进
        in_channels=[256, 512, 1024, 2048],  # resnet/res2net
        # in_channels=[64, 128, 320, 512],   # LSKNet
        # in_channels=[128, 256, 512, 1024],   # ConvNeXt
        # upsample_cfg=dict(mode='bilinear'),  # 自己修改的FPN的插值算法 双线性插值算法 效果也许会好点
        out_channels=256,
        num_outs=5),
    # -----------------------------------------------------------
    rpn_head=dict(
        type='OrientedRPNHead',
        in_channels=256,
        feat_channels=256,
        version=angle_version,
        anchor_generator=dict(
            type='AnchorGenerator',
            scales=[8],
            ratios=[0.5, 1.0, 2.0],
            strides=[4, 8, 16, 32, 64]),
        bbox_coder=dict(
            type='MidpointOffsetCoder',
            angle_range=angle_version,
            target_means=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            target_stds=[1.0, 1.0, 1.0, 1.0, 0.5, 0.5]),
        loss_cls=dict(
            type='CrossEntropyLoss', use_sigmoid=True, loss_weight=1.0),
        loss_bbox=dict(
            type='SmoothL1Loss', beta=0.1111111111111111, loss_weight=1.0)),
    roi_head=dict(
        type='OrientedStandardRoIHead',
        bbox_roi_extractor=dict(
            type='RotatedSingleRoIExtractor',
            roi_layer=dict(
                type='RoIAlignRotated',
                out_size=7,
                sample_num=2,
                clockwise=True),
            out_channels=256,
            featmap_strides=[4, 8, 16, 32]),
        bbox_head=dict(
            type='RotatedShared2FCBBoxHead',
            in_channels=256,
            fc_out_channels=1024,
            roi_feat_size=7,
            # num_classes=15,    # 修改自己重写的数据集的类别总数  -- dota原来
            num_classes=1,    # HRSC2016数据集类别数   不val的话这个值不影响 val需要改val的classwise=True
            bbox_coder=dict(
                type='DeltaXYWHAOBBoxCoder',
                angle_range=angle_version,
                norm_factor=None,
                edge_swap=True,
                proj_xy=True,
                target_means=(.0, .0, .0, .0, .0),
                target_stds=(0.1, 0.1, 0.2, 0.2, 0.1)),
            reg_class_agnostic=True,
            loss_cls=dict(
                type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0),
            loss_bbox=dict(type='SmoothL1Loss', beta=1.0, loss_weight=1.0))),
    train_cfg=dict(
        rpn=dict(
            assigner=dict(
                type='MaxIoUAssigner',
                pos_iou_thr=0.7,
                neg_iou_thr=0.3,
                min_pos_iou=0.3,
                match_low_quality=True,
                gpu_assign_thr=800,
                ignore_iof_thr=-1),
            sampler=dict(
                type='RandomSampler',
                num=256,
                pos_fraction=0.5,
                neg_pos_ub=-1,
                add_gt_as_proposals=False),
            allowed_border=0,
            pos_weight=-1,
            debug=False),
        rpn_proposal=dict(
            nms_pre=2000,
            max_per_img=2000,
            nms=dict(type='nms', iou_threshold=0.8),
            min_bbox_size=0),
        rcnn=dict(
            assigner=dict(
                type='MaxIoUAssigner',
                pos_iou_thr=0.5,
                neg_iou_thr=0.5,
                min_pos_iou=0.5,
                match_low_quality=False,
                iou_calculator=dict(type='RBboxOverlaps2D'),
                gpu_assign_thr=800,
                ignore_iof_thr=-1),
            sampler=dict(
                type='RRandomSampler',
                num=512,
                pos_fraction=0.25,
                neg_pos_ub=-1,
                add_gt_as_proposals=True),
            pos_weight=-1,
            debug=False)),
    test_cfg=dict(
        rpn=dict(
            nms_pre=2000,
            max_per_img=2000,
            nms=dict(type='nms', iou_threshold=0.8),
            min_bbox_size=0),
        rcnn=dict(
            nms_pre=2000,
            min_bbox_size=0,
            score_thr=0.05,
            nms=dict(iou_thr=0.1),
            max_per_img=2000)))

img_norm_cfg = dict(
    mean=[123.675, 116.28, 103.53], std=[58.395, 57.12, 57.375], to_rgb=True)
train_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='LoadAnnotations', with_bbox=True),
    dict(type='RResize', img_scale=(1024, 1024)),
    dict(
        type='RRandomFlip',
        flip_ratio=[0.25, 0.25, 0.25],
        direction=['horizontal', 'vertical', 'diagonal'],
        version=angle_version),
    dict(
        type='PolyRandomRotate',
        rotate_ratio=0.5,
        angles_range=180,
        auto_bound=False,
        rect_classes=[9, 11],
        version=angle_version),
    dict(type='Normalize', **img_norm_cfg),
    dict(type='Pad', size_divisor=32),
    dict(type='DefaultFormatBundle'),
    dict(type='Collect', keys=['img', 'gt_bboxes', 'gt_labels'])
]

data = dict(
    # samples_per_gpu=8,  默认lsk使用8刚好  一般为偶数
    samples_per_gpu=1,
    workers_per_gpu=2,
    # 一般为2 不修改
    train=dict(pipeline=train_pipeline, version=angle_version),
    val=dict(version=angle_version),
    test=dict(version=angle_version))

optimizer = dict(
    _delete_=True,
    type='AdamW',
    # lr=0.0002, #/8*gpu_number 太大，设置小一点,
    lr=0.00001, #/8*gpu_number 太大，设置小一点,  #IFEM
    betas=(0.9, 0.999),
    weight_decay=0.05,
    )
