import os
import os.path as osp

dir_path = '/xiaying_ms/bp/RSOD-dataset/DIOR/Annotations-trainval/Oriented-Bounding-Boxes'  # Annotations-trainval标注删除
# dir_path = '/xiaying_ms/bp/RSOD-dataset/DIOR/Annotations-test/Horizontal-Bounding-Boxes'     # Annotations-test标注删除
files = os.listdir(dir_path)
for file in files:
    if file > '11725.xml':  # 需要更换文件名 包括后缀
        file = osp.join(dir_path, file)
        os.remove(file)
        # print(file)
