#!/usr/bin/env bash

#CONFIG="/mnt/bp/Large-Selective-Kernel-Network/configs/lsknet/lsk_s_fpn_1x_dota_le90.py"
#CONFIG="/mnt/bp/Large-Selective-Kernel-Network/configs/lsknet/owner.py"
CONFIG="/mnt/bp/Large-Selective-Kernel-Network/configs/lsknet/my_hrsc.py"
#CONFIG="/mnt/bp/Large-Selective-Kernel-Network/configs/oriented_rcnn/oriented_rcnn_r50_fpn_1x_dota_le90.py"
#CHECKPOINT="/mnt/bp/Large-Selective-Kernel-Network/original_paper-checkpoints/lsk_s_fpn_1x_dota_le90_20230116-99749191.pth"
#CHECKPOINT="/mnt/bp/Large-Selective-Kernel-Network/original_paper-checkpoints/oriented_rcnn_r50_fpn_1x_dota_le90-6d2b2ce0.pth"
#CHECKPOINT="/mnt/bp/Large-Selective-Kernel-Network/checkpoints/change/MyNet/epoch_10.pth"
#CHECKPOINT="/mnt/bp/Large-Selective-Kernel-Network/checkpoints/change/HRSC/latest.pth"
CHECKPOINT="/mnt/bp/Large-Selective-Kernel-Network/checkpoints/change/HRSC/epoch_36.pth"
#CHECKPOINT="/mnt/bp/Large-Selective-Kernel-Network/checkpoints/change/HRSC/lsk_s_fpn_3x_hrsc_le90_20230205.pth"
#CHECKPOINT="/mnt/bp/Large-Selective-Kernel-Network/checkpoints/change/HRSC/O-RCNN-TrainVal/all-98.50/epoch_36.pth"
GPUS=2
NNODES=${NNODES:-1}
NODE_RANK=${NODE_RANK:-0}
PORT=${PORT:-29500}
MASTER_ADDR=${MASTER_ADDR:-"127.0.0.1"}

PYTHONPATH="/mnt/bp/Large-Selective-Kernel-Network/tools":$PYTHONPATH \
python -m torch.distributed.launch \
    --nnodes=$NNODES \
    --node_rank=$NODE_RANK \
    --master_addr=$MASTER_ADDR \
    --nproc_per_node=$GPUS \
    --master_port=$PORT \
     /mnt/bp/Large-Selective-Kernel-Network/tools/test.py \
    $CONFIG \
    $CHECKPOINT \
    --launcher pytorch \
    ${@:4} \
  	--show \
  	--eval mAP \
#    --format-only \--eval
#    --eval-options submission_dir=./Task1_results/Config4-1-0.00002-40.5h-TrainVal \
#  	--work-dir val-results/O-R-CNN-val \


  	
