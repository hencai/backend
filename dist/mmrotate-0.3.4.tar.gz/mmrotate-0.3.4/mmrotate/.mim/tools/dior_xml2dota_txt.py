# 文件名称   ：xml2dota2txt.py
# 功能描述   ：把rolabelimg标注的xml文件转换成dota能识别的xml文件，
#             再转换成dota格式的txt文件
#             把旋转框 cx,cy,w,h,angle，转换成四点坐标x1,y1,x2,y2,x3,y3,x4,y4
import os
import xml.etree.ElementTree as ET
import math


def totxt(xml_path, out_path):
    # 想要生成的txt文件保存的路径，这里可以自己修改

    files = os.listdir(xml_path)
    for file in files:

        tree = ET.parse(xml_path + os.sep + file)
        root = tree.getroot()

        name = file.strip('.xml')
        output = out_path + name + '.txt'
        file = open(output, 'w')

        objs = tree.findall('object')
        for obj in objs:
            cls = obj.find('name').text
            box = obj.find('robndbox')
            x0 = int(float(box.find('x_left_top').text))
            y0 = int(float(box.find('y_left_top').text))
            x1 = int(float(box.find('x_right_top').text))
            y1 = int(float(box.find('y_right_top').text))
            x2 = int(float(box.find('x_right_bottom').text))
            y2 = int(float(box.find('y_right_bottom').text))
            x3 = int(float(box.find('x_left_bottom').text))
            y3 = int(float(box.find('y_left_bottom').text))
            file.write("{} {} {} {} {} {} {} {} {} 0\n".format(x0, y0, x1, y1, x2, y2, x3, y3, cls))
        file.close()
        print(output)


if __name__ == '__main__':
    dotaxml_path = '/xiaying_ms/bp/RSOD-dataset/DIOR/Annotations-trainval/Oriented-Bounding-Boxes'  # 目录下保存的是需要转换为txt的xml文件
    out_path = '/xiaying_ms/bp/RSOD-dataset/DIOR/Annotations-trainval/dota_txt/'  # 保存txt文件的目录
    if not os.path.exists(out_path):
        os.mkdir(out_path)
    # -----**** 把旋转框xml文件转换成txt格式 ****-----
    totxt(dotaxml_path, out_path)
