import os
import random

# 设置要操作的文件夹路径
folder_path = "/xiaying_ms/bp/Large-Selective-Kernel-Network/data/split_ms_dota/test/annfiles"

# 获取文件夹中所有的txt文件
txt_files = [file for file in os.listdir(folder_path) if file.endswith('.txt')]

# 遍历每个txt文件并写入数据
for file_name in txt_files:
    with open(os.path.join(folder_path, file_name), 'w') as f:
        # 生成8个随机数并写入文件
        random_numbers = [random.randint(0, 3) for i in range(8)]
        f.write(' '.join(str(x) for x in random_numbers))
        f.write(' ship 0\n')