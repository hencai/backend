import torch
import torch.nn as nn
from .eca import eca_layer
from .se import SEBlock


class mlp_v8(nn.Module):   # 四分支，dilated maxpool avgpool residual connection  v8.0
    def __init__(self, dim):
        super().__init__()
        branch_channel = dim // 4
        self.conv_input = nn.Conv2d(dim, branch_channel, 1)
        self.branch1_1 = nn.Conv2d(branch_channel, branch_channel, 3, padding=1, dilation=1)
        self.branch1_2 = nn.Conv2d(branch_channel, branch_channel, 3, padding=3, dilation=3)
        self.branch1_3 = nn.Conv2d(branch_channel, branch_channel, 3, padding=5, dilation=5)
        self.branch2_1 = nn.MaxPool2d(kernel_size=3, stride=1, padding=1)
        self.branch2_2 = nn.MaxPool2d(kernel_size=5, stride=1, padding=2)
        self.branch2_3 = nn.MaxPool2d(kernel_size=7, stride=1, padding=3)
        self.branch3_1 = nn.AvgPool2d(kernel_size=3, stride=1, padding=1)
        self.branch3_2 = nn.AvgPool2d(kernel_size=5, stride=1, padding=2)
        self.branch3_3 = nn.AvgPool2d(kernel_size=7, stride=1, padding=3)
        self.norm = nn.LayerNorm(dim, eps=1e-6)  # 使用LN进行归一化
        self.att = eca_layer(dim)
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x):
        shortcut = x
        attn_in = self.conv_input(x)
        b1_1 = attn_in + self.branch1_1(attn_in)
        b1_2 = b1_1 + self.branch1_2(b1_1)
        b1_3 = b1_2 + self.branch1_3(b1_2)
        b2_1 = attn_in + self.branch2_1(attn_in)
        b2_2 = b2_1 + self.branch2_2(b2_1)
        b2_3 = b2_2 + self.branch2_3(b2_2)
        b3_1 = attn_in + self.branch3_1(attn_in)
        b3_2 = b3_1 + self.branch3_2(b3_1)
        b3_3 = b3_2 + self.branch3_3(b3_2)
        attn = torch.cat([b1_3, b2_3, b3_3, attn_in], dim=1)
        attn = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        attn = self.att(attn.permute(0, 3, 1, 2).contiguous())
        return shortcut * self.act_layer(attn)  # 6.0 这种方式效果好点


class mlp_v7(nn.Module):   # 灵感来自AGD-Linknet  v7.0
    def __init__(self, dim):
        super().__init__()
        small_channel = dim // 2
        tiny_channel = dim // 4
        self.conv_input = nn.Conv2d(dim, small_channel, 1)
        self.conv_small = nn.Conv2d(small_channel, tiny_channel, 1)
        self.max = nn.AdaptiveMaxPool2d(output_size=1)
        self.avg = nn.AdaptiveAvgPool2d(output_size=1)
        self.conv_3 = nn.Conv2d(tiny_channel, tiny_channel, 3, groups=tiny_channel, padding=1)
        self.conv_5 = nn.Conv2d(tiny_channel, tiny_channel, 5, groups=tiny_channel, padding=2)
        self.conv_fc = nn.Conv2d(tiny_channel, tiny_channel, 1,)
        self.conv_d1 = nn.Conv2d(small_channel, small_channel, 3, groups=small_channel, padding=1)
        self.conv_d2 = nn.Conv2d(small_channel, small_channel, 3, groups=small_channel, padding=2, dilation=2)
        self.conv_d5 = nn.Conv2d(small_channel, small_channel, 3, groups=small_channel, padding=5, dilation=5)
        self.conv_d9 = nn.Conv2d(small_channel, small_channel, 3, groups=small_channel, padding=9, dilation=9)
        self.conv_split = nn.Conv2d(2, 2, 7, padding=3)
        self.att = eca_layer(dim)
        self.bn = nn.BatchNorm2d(tiny_channel)
        self.norm = nn.LayerNorm(dim, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)
        self.conv_recover = nn.Conv2d(small_channel, dim, 1)

    def forward(self, x):
        shortcut = x
        attn_in = self.conv_input(x)
        branch_in = self.conv_small(attn_in)
        branch1_left = self.max(branch_in)
        branch1_left = self.conv_3(branch1_left)
        branch1_left = self.conv_5(branch1_left)
        branch1_left = branch_in + self.conv_fc(branch1_left)
        branch1_right = self.avg(branch_in)
        branch1_right = branch_in + self.act_layer(self.bn(branch1_right))
        branch2 = self.max(attn_in)
        branch2 = branch2 + self.conv_d1(branch2)
        branch2 = branch2 + self.conv_d2(branch2)
        branch2 = branch2 + self.conv_d5(branch2)
        branch2 = attn_in + branch2 + self.conv_d9(branch2)
        branch1 = torch.cat([branch1_left, branch1_right], dim=1)
        attn = torch.cat([branch1, branch2], dim=1)
        attn1 = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        attn1 = self.att(attn1.permute(0, 3, 1, 2).contiguous())
        avg_attn = torch.mean(attn, dim=1, keepdim=True)
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        agg = torch.cat([avg_attn, max_attn], dim=1)
        sig = self.conv_split(agg).sigmoid()
        attn2 = branch1 * sig[:, 0, :, :].unsqueeze(1) + branch2 * sig[:, 1, :, :].unsqueeze(1)
        attn_out = attn1 + self.conv_recover(attn2) + attn
        return shortcut * attn_out  # 6.0 这种方式效果好点


class mlp_v6_4(nn.Module):   # 新写的mlp还没有做实验  v6.3 在6.2的基础上删减分支 查看效果
    def __init__(self, dim):
        super().__init__()
        mid_channel = dim // 4
        sum_channel = mid_channel * 3
        self.conv_input = nn.Conv2d(dim, mid_channel, 1)
        self.conv_fc = nn.Conv2d(mid_channel, mid_channel, 1)
        self.conv_common = nn.Conv2d(mid_channel, mid_channel, 3, padding=1)
        self.conv_branch2_1 = nn.Conv2d(mid_channel, mid_channel, 3, padding=2, dilation=2)
        self.conv_branch2_2 = nn.Conv2d(mid_channel, mid_channel, 3, padding=5, dilation=5)
        self.conv_branch2_3 = nn.Conv2d(mid_channel, mid_channel, 3, padding=7, dilation=7)

        self.conv_split = nn.Conv2d(2, 3, 7, padding=3)
        # self.att = eca_layer(sum_channel)
        self.bn = nn.BatchNorm2d(mid_channel)
        # self.norm = nn.LayerNorm(sum_channel, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)
        self.conv_recover1 = nn.Conv2d(sum_channel, dim, 1)
        self.conv_recover2 = nn.Conv2d(dim // 4, sum_channel, 1)

    def forward(self, x):
        shortcut = x
        attn_in = self.conv_input(x)
        attn_left = self.act_layer(self.bn(attn_in))
        attn_left1 = self.conv_common(attn_in)
        attn_left2 = attn_left1 + self.conv_fc(attn_left1)
        attn_left = attn_left + attn_left2

        attn_right1 = self.conv_branch2_1(attn_in)
        attn_right2 = attn_right1 + self.conv_branch2_2(attn_right1)
        attn_right3 = self.conv_fc(attn_right2 + self.conv_branch2_3(attn_right2))

        attn = torch.cat([attn_right1, attn_right2, attn_right3], dim=1)
        # attn_branch1 = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        # attn_branch1 = self.att(attn_branch1.permute(0, 3, 1, 2).contiguous())
        avg_attn = torch.mean(attn, dim=1, keepdim=True)
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        agg = torch.cat([avg_attn, max_attn], dim=1)
        sig = self.conv_split(agg).sigmoid()
        attn_branch = attn_right1 * sig[:, 0, :, :].unsqueeze(1) + attn_right2 * sig[:, 1, :, :].unsqueeze(1) + attn_right3 * sig[:, 2, :, :].unsqueeze(1)
        # 原始版本 ----------
        # attn_out = attn_branch1 + self.conv_recover2(attn_branch2) + attn + self.conv_recover2(attn_left)
        attn_out = self.conv_recover2(attn_branch) + attn + self.conv_recover2(attn_left)
        attn_out = self.conv_recover1(attn_out)
        # -------以下改进下降 不需要----------
        # attn_out = torch.cat([attn_branch1 + self.conv_recover2(attn_branch2) + attn, attn_left], dim=1)
        # 试验版本 60.2 -59.4
        return shortcut * attn_out  # 6.0 原始训练测试的 59.1
        # return attn_out    # 想要测试改变的  59.1 到 57.4 效果下降


class mlp_v6_3(nn.Module):   # 新写的mlp还没有做实验  v6.3 在6.2的基础上删减分支 查看效果
    def __init__(self, dim):
        super().__init__()
        mid_channel = dim // 4
        sum_channel = mid_channel * 3
        self.conv_input = nn.Conv2d(dim, mid_channel, 1)
        self.conv_fc = nn.Conv2d(mid_channel, mid_channel, 1)
        self.conv_common = nn.Conv2d(mid_channel, mid_channel, 3, padding=1)
        self.conv_branch1 = nn.Conv2d(mid_channel, mid_channel, 5, padding=2)
        self.conv_branch2_1 = nn.Conv2d(mid_channel, mid_channel, 3, padding=3, dilation=3)
        self.conv_branch2_2 = nn.Conv2d(mid_channel, mid_channel, 3, padding=5, dilation=5)

        self.conv_split = nn.Conv2d(2, 3, 7, padding=3)
        # self.att = eca_layer(sum_channel)
        self.bn = nn.BatchNorm2d(mid_channel)
        # self.norm = nn.LayerNorm(sum_channel, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)
        self.conv_recover1 = nn.Conv2d(sum_channel, dim, 1)
        self.conv_recover2 = nn.Conv2d(dim // 4, sum_channel, 1)

    def forward(self, x):
        shortcut = x
        attn_in = self.conv_input(x)
        attn_left = self.act_layer(self.bn(attn_in))
        attn_left1 = self.conv_fc(attn_in)
        attn_left2 = attn_left1 + self.conv_common(attn_left1)
        attn_left3 = attn_left2 + self.conv_branch1(attn_left2)
        attn_left = attn_left + attn_left3

        attn_right1 = self.conv_fc(attn_in)
        attn_right2 = attn_right1 + self.conv_common(attn_right1)
        attn_right3 = attn_right2 + self.conv_branch2_1(attn_right2)
        attn_right4 = attn_right3 + self.conv_branch2_2(attn_right3)

        attn1 = attn_left1 + attn_right2
        attn2 = attn_left2 + attn_right1
        attn3 = attn_left3 + attn_right3 + attn_right4

        attn = torch.cat([attn1, attn2, attn3], dim=1)
        # attn_branch1 = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        # attn_branch1 = self.att(attn_branch1.permute(0, 3, 1, 2).contiguous())
        avg_attn = torch.mean(attn, dim=1, keepdim=True)
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        agg = torch.cat([avg_attn, max_attn], dim=1)
        sig = self.conv_split(agg).sigmoid()
        attn_branch2 = attn1 * sig[:, 0, :, :].unsqueeze(1) + attn2 * sig[:, 1, :, :].unsqueeze(1) + attn3 * sig[:, 2, :, :].unsqueeze(1)
        # 原始版本 ----------
        # attn_out = attn_branch1 + self.conv_recover2(attn_branch2) + attn + self.conv_recover2(attn_left)
        attn_out = self.conv_recover2(attn_branch2) + attn + self.conv_recover2(attn_left)
        attn_out = self.conv_recover1(attn_out)
        # -------以下改进下降 不需要----------
        # attn_out = torch.cat([attn_branch1 + self.conv_recover2(attn_branch2) + attn, attn_left], dim=1)
        # 试验版本 60.2 -59.4
        return shortcut * attn_out  # 6.0 原始训练测试的 59.1
        # return attn_out    # 想要测试改变的  59.1 到 57.4 效果下降


class mlp_v6_2(nn.Module):   # 新写的mlp还没有做实验  v6.0
    def __init__(self, dim):
        super().__init__()
        mid_channel = dim // 4
        sum_channel = mid_channel * 3
        self.conv_input = nn.Conv2d(dim, mid_channel, 1)
        self.conv_fc = nn.Conv2d(mid_channel, mid_channel, 1)
        self.conv_common = nn.Conv2d(mid_channel, mid_channel, 3, padding=1)
        self.conv_branch1 = nn.Conv2d(mid_channel, mid_channel, 5, padding=2)
        self.conv_branch2_1 = nn.Conv2d(mid_channel, mid_channel, 3, padding=3, dilation=3)
        self.conv_branch2_2 = nn.Conv2d(mid_channel, mid_channel, 3, padding=5, dilation=5)

        self.conv_split = nn.Conv2d(2, 3, 7, padding=3)
        self.att = eca_layer(sum_channel)
        self.bn = nn.BatchNorm2d(mid_channel)
        self.norm = nn.LayerNorm(sum_channel, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)
        self.conv_recover1 = nn.Conv2d(sum_channel, dim, 1)
        self.conv_recover2 = nn.Conv2d(dim // 4, sum_channel, 1)

    def forward(self, x):
        shortcut = x
        attn_in = self.conv_input(x)
        attn_left = self.act_layer(self.bn(attn_in))
        attn_left1 = self.conv_fc(attn_in)
        attn_left2 = attn_left1 + self.conv_common(attn_left1)
        attn_left3 = attn_left2 + self.conv_branch1(attn_left2)
        attn_left = attn_left + attn_left3

        attn_right1 = self.conv_fc(attn_in)
        attn_right2 = attn_right1 + self.conv_common(attn_right1)
        attn_right3 = attn_right2 + self.conv_branch2_1(attn_right2)
        attn_right4 = attn_right3 + self.conv_branch2_2(attn_right3)

        attn1 = attn_left1 + attn_right2
        attn2 = attn_left2 + attn_right1
        attn3 = attn_left3 + attn_right3 + attn_right4

        attn = torch.cat([attn1, attn2, attn3], dim=1)
        attn_branch1 = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        attn_branch1 = self.att(attn_branch1.permute(0, 3, 1, 2).contiguous())
        avg_attn = torch.mean(attn, dim=1, keepdim=True)
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        agg = torch.cat([avg_attn, max_attn], dim=1)
        sig = self.conv_split(agg).sigmoid()
        attn_branch2 = attn1 * sig[:, 0, :, :].unsqueeze(1) + attn2 * sig[:, 1, :, :].unsqueeze(1) + attn3 * sig[:, 2, :, :].unsqueeze(1)
        # 原始版本 ----------
        attn_out = attn_branch1 + self.conv_recover2(attn_branch2) + attn + self.conv_recover2(attn_left)
        attn_out = self.conv_recover1(attn_out)
        # -------以下改进下降 不需要----------
        # attn_out = torch.cat([attn_branch1 + self.conv_recover2(attn_branch2) + attn, attn_left], dim=1)
        # 试验版本 60.2 -59.4
        return shortcut * attn_out  # 6.0 原始训练测试的 59.1
        # return attn_out    # 想要测试改变的  59.1 到 57.4 效果下降


class mlp_v6(nn.Module):   # 新写的mlp还没有做实验  v6.0
    def __init__(self, dim):
        super().__init__()
        mid_channel = dim // 4
        sum_channel = mid_channel * 3
        self.conv_input = nn.Conv2d(dim, mid_channel, 1)
        self.conv_fc = nn.Conv2d(mid_channel, mid_channel, 1)
        self.conv_common = nn.Conv2d(mid_channel, mid_channel, 3, padding=1)
        self.conv_branch1 = nn.Conv2d(mid_channel, mid_channel, 5, padding=2)
        self.conv_branch2_1 = nn.Conv2d(mid_channel, mid_channel, 3, padding=3, dilation=3)
        self.conv_branch2_2 = nn.Conv2d(mid_channel, mid_channel, 3, padding=5, dilation=5)

        self.conv_split = nn.Conv2d(2, 3, 7, padding=3)
        self.att = eca_layer(sum_channel)
        self.bn = nn.BatchNorm2d(mid_channel)
        self.norm = nn.LayerNorm(sum_channel, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)
        self.conv_recover1 = nn.Conv2d(sum_channel, dim, 1)
        self.conv_recover2 = nn.Conv2d(dim // 4, sum_channel, 1)

    def forward(self, x):
        shortcut = x
        attn_in = self.conv_input(x)
        attn_left = self.act_layer(self.bn(attn_in))
        attn_left1 = self.conv_fc(attn_left)
        attn_left2 = attn_left1 + self.conv_common(attn_left)
        attn_left3 = attn_left2 + self.conv_branch1(attn_left)

        attn_right1 = self.conv_fc(attn_in)
        attn_right2 = attn_right1 + self.conv_common(attn_in)
        attn_right3 = attn_right2 + self.conv_branch2_1(attn_in)
        attn_right4 = attn_right3 + self.conv_branch2_2(attn_in)

        attn1 = attn_left1 + attn_right2
        attn2 = attn_left2 + attn_right1
        attn3 = attn_left3 + attn_right3 + attn_right4

        attn = torch.cat([attn1, attn2, attn3], dim=1)
        attn_branch1 = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        attn_branch1 = self.att(attn_branch1.permute(0, 3, 1, 2).contiguous())
        avg_attn = torch.mean(attn, dim=1, keepdim=True)
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        agg = torch.cat([avg_attn, max_attn], dim=1)
        sig = self.conv_split(agg).sigmoid()
        attn_branch2 = attn1 * sig[:, 0, :, :].unsqueeze(1) + attn2 * sig[:, 1, :, :].unsqueeze(1) + attn3 * sig[:, 2, :, :].unsqueeze(1)
        attn_out = attn_branch1 + self.conv_recover2(attn_branch2) + attn
        attn_out = self.conv_recover1(attn_out)
        return shortcut * attn_out  # 6.0 原始训练测试的 59.1
        # return attn_out    # 想要测试改变的  59.1 到 57.4 效果下降


class mlp_v5(nn.Module):   # 新写的mlp还没有做实验  v5.0   对比同时使用se和eca 进行加运算
    def __init__(self, dim):
        super().__init__()
        compress_channel = dim // 32
        branch_channel = dim // 5
        last_branch_channel = dim - 4 * branch_channel
        self.channel_compress = nn.Conv2d(dim, compress_channel, 1)
        self.conv_branch1 = nn.Conv2d(compress_channel, last_branch_channel, 3, padding=1, dilation=1)
        self.conv_branch2 = nn.Conv2d(compress_channel, branch_channel, 3, padding=3, dilation=3)
        self.conv_branch3 = nn.Conv2d(compress_channel, branch_channel, 3, padding=5, dilation=5)
        self.conv_branch4 = nn.Conv2d(compress_channel, branch_channel, 3, padding=7, dilation=7)
        self.conv_branch5 = nn.Conv2d(compress_channel, branch_channel, 3, padding=9, dilation=9)
        self.att1 = SEBlock(dim)    # 对比v2.0修改了注意力
        self.att2 = eca_layer(dim)   # 新添加的注意力
        self.norm = nn.LayerNorm(dim, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x):
        shortcut = x
        attn_in = self.channel_compress(x)
        attn1 = self.conv_branch1(attn_in)
        attn2 = self.conv_branch2(attn_in)
        attn3 = attn2 + self.conv_branch3(attn_in)
        attn4 = attn3 + self.conv_branch4(attn_in)
        attn5 = attn4 + self.conv_branch5(attn_in)
        attn = torch.cat([attn1, attn2, attn3, attn4, attn5], dim=1) + shortcut
        attn = self.norm(attn.permute(0, 2, 3, 1).contiguous()).permute(0, 3, 1, 2).contiguous()
        attn = self.att1(attn) + self.att2(attn)
        return self.act_layer(attn)


class mlp_v4(nn.Module):   # 新写的mlp还没有做实验  v4.0   借鉴ESPNet的思想
    def __init__(self, dim):
        super().__init__()
        compress_channel = dim // 32
        branch_channel = dim // 5
        last_branch_channel = dim - 4 * branch_channel
        self.channel_compress = nn.Conv2d(dim, compress_channel, 1)
        self.conv_branch1 = nn.Conv2d(compress_channel, last_branch_channel, 3, padding=1, dilation=1)
        self.conv_branch2 = nn.Conv2d(compress_channel, branch_channel, 3, padding=3, dilation=3)
        self.conv_branch3 = nn.Conv2d(compress_channel, branch_channel, 3, padding=5, dilation=5)
        self.conv_branch4 = nn.Conv2d(compress_channel, branch_channel, 3, padding=7, dilation=7)
        self.conv_branch5 = nn.Conv2d(compress_channel, branch_channel, 3, padding=9, dilation=9)
        self.att = SEBlock(dim)    # 对比v2.0修改了注意力
        self.norm = nn.LayerNorm(dim, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x):
        shortcut = x
        attn_in = self.channel_compress(x)
        attn1 = self.conv_branch1(attn_in)
        attn2 = self.conv_branch2(attn_in)
        attn3 = attn2 + self.conv_branch3(attn_in)
        attn4 = attn3 + self.conv_branch4(attn_in)
        attn5 = attn4 + self.conv_branch5(attn_in)
        attn = torch.cat([attn1, attn2, attn3, attn4, attn5], dim=1) + shortcut
        attn = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        attn = self.att(attn.permute(0, 3, 1, 2).contiguous())
        return self.act_layer(attn)


class mlp_v3(nn.Module):   # 新写的mlp还没有做实验  v3.0
    def __init__(self, dim):
        super().__init__()
        small_channel = dim // 16
        tiny_channel = dim // 32
        sum_channel = small_channel * 3 + tiny_channel
        self.conv1 = nn.Conv2d(dim, small_channel, 1)
        self.conv2 = nn.Conv2d(dim, tiny_channel, 1)
        self.pool = nn.MaxPool2d(kernel_size=3, stride=1, padding=1)
        self.conv_branch_1 = nn.Conv2d(small_channel, small_channel, 3, padding=3, groups=small_channel, dilation=3)
        self.conv_branch_2 = nn.Conv2d(tiny_channel, tiny_channel, 3, padding=5, groups=tiny_channel, dilation=5)
        self.pool_proj = nn.Conv2d(dim, small_channel, 1)
        self.att = eca_layer(sum_channel)    # 对比v2.0修改了注意力
        self.norm = nn.LayerNorm(sum_channel, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)
        self.channel_recover = nn.Conv2d(sum_channel, dim, 1)

    def forward(self, x):
        shortcut = x
        attn0 = self.conv1(x)
        attn1 = self.conv2(x)
        attn2 = self.pool(x)
        attn0_1 = self.conv_branch_1(attn0)
        attn1 = self.conv_branch_2(attn1)
        attn2 = self.pool_proj(attn2)
        attn = torch.cat([attn0, attn0_1, attn1, attn2], dim=1)
        attn = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        attn = self.att(attn.permute(0, 3, 1, 2).contiguous())
        attn = self.act_layer(attn)
        return self.channel_recover(attn)


class mlp_v2(nn.Module):   # 新写的mlp还没有做实验  v2.0
    def __init__(self, dim):
        super().__init__()
        small_channel = dim // 16
        tiny_channel = dim // 32
        sum_channel = small_channel * 3 + tiny_channel
        self.conv1 = nn.Conv2d(dim, small_channel, 1)
        self.conv2 = nn.Conv2d(dim, tiny_channel, 1)
        self.pool = nn.MaxPool2d(kernel_size=3, stride=1, padding=1)
        self.conv_branch_1 = nn.Conv2d(small_channel, small_channel, 3, padding=3, groups=small_channel, dilation=3)
        self.conv_branch_2 = nn.Conv2d(tiny_channel, tiny_channel, 3, padding=5, groups=tiny_channel, dilation=5)
        self.pool_proj = nn.Conv2d(dim, small_channel, 1)
        self.att = SEBlock(sum_channel)
        self.norm = nn.LayerNorm(sum_channel, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)
        self.channel_recover = nn.Conv2d(sum_channel, dim, 1)

    def forward(self, x):
        shortcut = x
        attn0 = self.conv1(x)
        attn1 = self.conv2(x)
        attn2 = self.pool(x)
        attn0_1 = self.conv_branch_1(attn0)
        attn1 = self.conv_branch_2(attn1)
        attn2 = self.pool_proj(attn2)
        attn = torch.cat([attn0, attn0_1, attn1, attn2], dim=1)
        attn = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        attn = self.att(attn.permute(0, 3, 1, 2).contiguous())
        attn = self.act_layer(attn)
        return self.channel_recover(attn)


# class mlp_v1(nn.Module):   # 新写的mlp还没有做实验  v1.0
#     def __init__(self, dim):
#         super().__init__()
#         mid_channel = dim // 16
#         out_channel = dim // 4
#         self.conv1 = nn.Conv2d(dim, mid_channel, 1)
#         self.conv2_1 = nn.Conv2d(mid_channel, mid_channel, 3, padding=1, groups=mid_channel, dilation=1)
#         self.conv2_2 = nn.Conv2d(mid_channel, mid_channel, 3, padding=3, groups=mid_channel, dilation=3)
#         self.conv2_3 = nn.Conv2d(mid_channel, mid_channel, 3, padding=5, groups=mid_channel, dilation=5)
#         self.conv3 = nn.Conv2d(out_channel, mid_channel, 1)
#         self.pool = nn.AdaptiveAvgPool2d(output_size=1)
#         self.conv_back = nn.Conv2d(mid_channel, dim, 1)
#         # self.norm = nn.LayerNorm(dim, eps=1e-6)  # 使用LN进行归一化
#         # self.att = eca_layer(dim)
#         self.act_layer = nn.ReLU(inplace=True)
#         self.sigmoid = nn.Sigmoid()
#
#     def forward(self, x):
#         shortcut = x
#         attn0 = self.conv1(x)
#         attn1 = self.conv2_1(attn0)
#         attn2 = attn1 + self.conv2_2(attn0)
#         attn3 = attn2 + self.conv2_3(attn0)
#         attn = torch.cat([attn0, attn1, attn2, attn3], dim=1)
#         attn = self.act_layer(self.pool(self.conv3(attn)))
#         attn = self.sigmoid(self.conv_back(attn))
#         # attn = self.norm(attn.permute(0, 2, 3, 1).contiguous())
#         # attn = self.att(attn.permute(0, 3, 1, 2).contiguous())
#         return shortcut * attn


class DepthwiseSeparableConv(nn.Module):           # 原始没有dilation   自己修改的版本有dilation
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, dilation=1):
        super(DepthwiseSeparableConv, self).__init__()

        if isinstance(kernel_size, int):
            padding = dilation * (kernel_size - 1) // 2
        else:
            padding = (dilation * (k - 1) // 2 for k in kernel_size)
        # 深度卷积层
        self.depthwise = nn.Sequential(nn.Conv2d(in_channels, in_channels, kernel_size,
                                                 stride, padding, groups=in_channels, dilation=dilation),
                                       nn.BatchNorm2d(in_channels),
                                       # activation_layer
                                       nn.LeakyReLU(0.1, inplace=True)
                                       )
        # 逐点卷积层
        self.pointwise = nn.Sequential(nn.Conv2d(in_channels, out_channels, 1),
                                       nn.BatchNorm2d(out_channels),
                                       # activation_layer
                                       nn.LeakyReLU(0.1, inplace=True)
                                       )

    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        return x
