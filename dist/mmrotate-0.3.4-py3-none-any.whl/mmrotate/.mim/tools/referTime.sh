#!/usr/bin/env bash


python -m torch.distributed.launch \
       --nproc_per_node=1 \
       --master_port=29500 \
       tools/analysis_tools/benchmark.py \
       configs/redet/redet_re50_refpn_3x_hrsc_le90.py \
       work_dirs/redet_re50_refpn_3x_hrsc_le90/epoch_1.pth \
       --launcher pytorch
