from thop import profile
from 
flops, params = profile(model, inputs=(input, ))
print('FLOPs:', flops)