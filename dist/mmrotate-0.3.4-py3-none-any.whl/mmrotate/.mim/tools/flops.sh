#!/usr/bin/env bash

#python tools/analysis_tools/get_flops.py configs/lsknet/my_hrsc.py --shape 1024 1024
#python tools/analysis_tools/get_flops.py configs/lsknet/owner.py --shape 1024 1024
#python tools/analysis_tools/get_flops.py configs/oriented_rcnn/oriented_rcnn_r50_fpn_1x_dota_le90.py --shape 1024 1024
python tools/analysis_tools/get_flops.py configs/lsknet/lsk_s_fpn_1x_dota_le90.py --shape 1024 1024