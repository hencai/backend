# Copyright (c) OpenMMLab. All rights reserved.
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import ConvModule
from mmcv.runner import BaseModule, auto_fp16

from mmdet.models.builder import NECKS
from ..backbones.atts_blocks.se import SEBlock
from ..backbones.atts_blocks.eca import eca_layer
from ..backbones.atts_blocks.self_mlp import DepthwiseSeparableConv
from ..backbones.atts_blocks.Neck_block import DownSampEnhance_v3
from ..backbones.atts_blocks.Neck_block import DownSampEnhance_v4


@NECKS.register_module()
class SSFPN(BaseModule):
    r"""Feature Pyramid Network.

    This is an implementation of paper `Feature Pyramid Networks for Object
    Detection <https://arxiv.org/abs/1612.03144>`_.

    Args:
        in_channels (list[int]): Number of input channels per scale.
        out_channels (int): Number of output channels (used at each scale).
        num_outs (int): Number of output scales.
        start_level (int): Index of the start input backbone level used to
            build the feature pyramid. Default: 0.
        end_level (int): Index of the end input backbone level (exclusive) to
            build the feature pyramid. Default: -1, which means the last level.
        add_extra_convs (bool | str): If bool, it decides whether to add conv
            layers on top of the original feature maps. Default to False.
            If True, it is equivalent to `add_extra_convs='on_input'`.
            If str, it specifies the source feature map of the extra convs.
            Only the following options are allowed

            - 'on_input': Last feat map of neck inputs (i.e. backbone feature).
            - 'on_lateral': Last feature map after lateral convs.
            - 'on_output': The last output feature map after fpn convs.
        relu_before_extra_convs (bool): Whether to apply relu before the extra
            conv. Default: False.
        no_norm_on_lateral (bool): Whether to apply norm on lateral.
            Default: False.
        conv_cfg (dict): Config dict for convolution layer. Default: None.
        norm_cfg (dict): Config dict for normalization layer. Default: None.
        act_cfg (dict): Config dict for activation layer in ConvModule.
            Default: None.
        upsample_cfg (dict): Config dict for interpolate layer.
            Default: dict(mode='nearest').
        init_cfg (dict or list[dict], optional): Initialization config dict.

    Example:
        >>> import torch
        >>> in_channels = [2, 3, 5, 7]
        >>> scales = [340, 170, 84, 43]
        >>> inputs = [torch.rand(1, c, s, s)
        ...           for c, s in zip(in_channels, scales)]
        >>> self = FPN(in_channels, 11, len(in_channels)).eval()
        >>> outputs = self.forward(inputs)
        >>> for i in range(len(outputs)):
        ...     print(f'outputs[{i}].shape = {outputs[i].shape}')
        outputs[0].shape = torch.Size([1, 11, 340, 340])
        outputs[1].shape = torch.Size([1, 11, 170, 170])
        outputs[2].shape = torch.Size([1, 11, 84, 84])
        outputs[3].shape = torch.Size([1, 11, 43, 43])
    """

    def __init__(self,
                 in_channels,
                 out_channels,
                 num_outs,
                 start_level=0,
                 end_level=-1,
                 add_extra_convs=False,
                 relu_before_extra_convs=False,
                 no_norm_on_lateral=False,
                 conv_cfg=None,
                 norm_cfg=None,
                 act_cfg=None,
                 upsample_cfg=dict(mode='nearest'),
                 init_cfg=dict(
                     type='Xavier', layer='Conv2d', distribution='uniform')):
        super(SSFPN, self).__init__(init_cfg)
        assert isinstance(in_channels, list)
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_ins = len(in_channels)
        self.num_outs = num_outs
        self.relu_before_extra_convs = relu_before_extra_convs
        self.no_norm_on_lateral = no_norm_on_lateral
        self.fp16_enabled = False
        self.upsample_cfg = upsample_cfg.copy()

        if end_level == -1 or end_level == self.num_ins - 1:
            self.backbone_end_level = self.num_ins
            assert num_outs >= self.num_ins - start_level
        else:
            # if end_level is not the last level, no extra level is allowed
            self.backbone_end_level = end_level + 1
            assert end_level < self.num_ins
            assert num_outs == end_level - start_level + 1
        self.start_level = start_level
        self.end_level = end_level
        self.add_extra_convs = add_extra_convs
        assert isinstance(add_extra_convs, (str, bool))
        if isinstance(add_extra_convs, str):
            # Extra_convs_source choices: 'on_input', 'on_lateral', 'on_output'
            assert add_extra_convs in ('on_input', 'on_lateral', 'on_output')
        elif add_extra_convs:  # True
            self.add_extra_convs = 'on_input'

        self.lateral_convs = nn.ModuleList()
        self.fpn_convs = nn.ModuleList()

        # --------------------------------------
        # self.add_dynamic_convs = nn.ModuleList()
        # self.before_convs = nn.ModuleList()
        # self.down_pool_convs = nn.ModuleList()
        # self.down_pool_norms = nn.ModuleList()
        # self.downsamp_modules = nn.ModuleList()
        self.shallow_deeps = nn.ModuleList()
        self.eca = eca_layer(256)
        # --------------------------------------

        dynamic_d = (7, 5, 3, 1)
        dpc_d = [5, 7]
        dm_d = [9, 7, 5]
        # shallow_deeps_strides = [8, 4]
        shallow_deeps_strides = [8, 4, 2]    # 待测  nan
        for i in range(self.start_level, self.backbone_end_level):
            # --------------------------------------
            # before_conv = nn.Conv2d(in_channels[i], out_channels, 1)
            # ------------------------------------------------原始-------------------------------------------------------
            l_conv = ConvModule(
                in_channels[i],
                out_channels,
                1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg if not self.no_norm_on_lateral else None,
                act_cfg=act_cfg,
                inplace=False)
            # ----------------------------------------------------------------------------------------------------------
            # l_conv = ConvModule(
            #     out_channels,
            #     out_channels,
            #     3,
            #     dilation=dynamic_d[i],
            #     padding=dynamic_d[i],
            #     conv_cfg=conv_cfg,
            #     norm_cfg=norm_cfg if not self.no_norm_on_lateral else None,
            #     act_cfg=act_cfg,
            #     inplace=False)
            # ----------------------------------------------------------------------------------------------------------


            # --------------------------------
            # add_dynamic_conv = eca_layer(out_channels)
            # if i < 2:
                # dpc = DepthwiseSeparableConv(out_channels, out_channels, 3, dilation=dpc_d.pop())
                # self.down_pool_convs.append(dpc)
                # dpn = nn.BatchNorm2d(out_channels)
                # self.down_pool_norms.append(dpn)
            # --------------------------------
            # if i < 3:
            #     dm = DownSampEnhance_v3(256, dm_d[i])
            #     self.downsamp_modules.append(dm)
            # --------------------------------
            # if i < 2:
            if i < 3:
                sd = DownSampEnhance_v4(shallow_deeps_strides[i])
                self.shallow_deeps.append(sd)
            # --------------------------------
            fpn_conv = ConvModule(
                out_channels,
                out_channels,
                3,
                padding=1,
                # padding=dynamic_d[i],
                # dilation=dynamic_d[i],
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
                inplace=False)

            self.lateral_convs.append(l_conv)
            self.fpn_convs.append(fpn_conv)

            # self.add_dynamic_convs.append(add_dynamic_conv)
            # self.before_convs.append(before_conv)

        # add extra conv layers (e.g., RetinaNet)
        extra_levels = num_outs - self.backbone_end_level + self.start_level
        if self.add_extra_convs and extra_levels >= 1:
            for i in range(extra_levels):
                if i == 0 and self.add_extra_convs == 'on_input':
                    in_channels = self.in_channels[self.backbone_end_level - 1]
                else:
                    in_channels = out_channels
                extra_fpn_conv = ConvModule(
                    in_channels,
                    out_channels,
                    3,
                    stride=2,
                    padding=1,
                    conv_cfg=conv_cfg,
                    norm_cfg=norm_cfg,
                    act_cfg=act_cfg,
                    inplace=False)
                self.fpn_convs.append(extra_fpn_conv)
        # --------------------------------------------------------------------------------------------------------------
        # self.d_convs = nn.ModuleList()
        # for i in (7, 5, 3):
        #     d_conv = nn.Conv2d(256, 256, 3, padding=i, dilation=i)
        #     self.d_convs.append(d_conv)
        # self.conv_fc = nn.Conv2d(256, 256, 1)
        # self.conv_fc2 = nn.Conv2d(256, 256, 1)
        # self.max_pool = nn.MaxPool2d(5, padding=2, stride=2)
        # self.eca = eca_layer(256)
        # self.d_conv = DepthwiseSeparableConv(256, 256, 5, dilation=7)
        #
        # self.down_samp1 = nn.Conv2d(256, 256, 3, stride=2, padding=1)
        # self.down_samp2 = nn.Conv2d(256, 256, 3, stride=4, padding=1)
        # self.conv_squeeze = nn.Conv2d(2, 2, 7, padding=3)
        # self.conv_fc = nn.Conv2d(256, 256, 1)
        # self.fc_norm = nn.BatchNorm2d(256)
        # self.norm_act = nn.ReLU(inplace=True)
        self.max_pool = nn.MaxPool2d(3, padding=1, stride=2)
        dim = 256
        self.conv0 = nn.Conv2d(dim, dim, 5, padding=2, groups=dim)
        self.conv_spatial = nn.Conv2d(dim, dim, 7, stride=1, padding=9, groups=dim, dilation=3)
        self.conv1 = nn.Conv2d(dim, dim // 2, 1)
        self.conv2 = nn.Conv2d(dim, dim // 2, 1)
        self.conv_squeeze = nn.Conv2d(2, 2, 7, padding=3)
        self.conv = nn.Conv2d(dim // 2, dim, 1)

        # self.my_eca = my_eca_layer(256)
        # self.derive_conv = nn.Conv2d(256, 256, 3, dilation=3, padding=3)
        # --------------------------------------------------------------------------------------------------------------

    @auto_fp16()
    def forward(self, inputs):
        """Forward function."""
        assert len(inputs) == len(self.in_channels)


        # build laterals
        laterals = [
            lateral_conv(inputs[i + self.start_level])
            for i, lateral_conv in enumerate(self.lateral_convs)
        ]
        # --------------------------------------------------------------------------------------------------------------
        # laterals = [
        #     before_conv(inputs[i + self.start_level])
        #     for i, before_conv in enumerate(self.before_convs)
        # ]
        #
        # for i in range(len(laterals)):
        #     laterals[i] = self.lateral_convs[i](laterals[i])
        # --------------------------------------------------------------------------------------------------------------

        # for i, add_dynamic_conv in enumerate(self.add_dynamic_convs):
        #     laterals[i] = laterals[i] + laterals[i] * add_dynamic_conv(laterals[i])

        # build top-down path
        # used_backbone_levels = len(laterals)
        # for i in range(used_backbone_levels - 1, 0, -1):
        #     # In some cases, fixing `scale factor` (e.g. 2) is preferred, but
        #     #  it cannot co-exist with `size` in `F.interpolate`.
        #     if 'scale_factor' in self.upsample_cfg:
        #         # fix runtime error of "+=" inplace operation in PyTorch 1.10
        #         laterals[i - 1] = laterals[i - 1] + F.interpolate(
        #             laterals[i], **self.upsample_cfg)
        #     else:
        #         prev_shape = laterals[i - 1].shape[2:]
        #         laterals[i - 1] = laterals[i - 1] + F.interpolate(
        #             laterals[i], size=prev_shape, **self.upsample_cfg)
        # --------------------------------------------------------------------------------------------------------------
        used_backbone_levels = len(laterals)
        for i in range(used_backbone_levels - 1, 0, -1):
            prev_shape = laterals[i - 1].shape[2:]
            up_result = F.interpolate(laterals[i], size=prev_shape, **self.upsample_cfg)
            if i > 1:
                down_result = self.max_pool(laterals[i - 2])
                # down_result = self.down_pool_convs[i - 2](self.max_pool(laterals[i - 2]))
                # down_result = self.down_pool_convs[i - 2](self.max_pool(self.down_pool_norms[i - 2](laterals[i - 2])))
                # down_result = self.down_pool_norms[i - 2](self.down_pool_convs[i - 2](self.max_pool(laterals[i - 2]))) # 不行
                attn_in = down_result + up_result
                attn1 = self.conv0(attn_in)
                attn2 = self.conv_spatial(attn1)

                attn1 = self.conv1(attn1)
                attn2 = self.conv2(attn2)

                attn = torch.cat([attn1, attn2], dim=1)
                avg_attn = torch.mean(attn, dim=1, keepdim=True)
                max_attn, _ = torch.max(attn, dim=1, keepdim=True)
                agg = torch.cat([avg_attn, max_attn], dim=1)
                sig = self.conv_squeeze(agg).sigmoid()
                attn = attn1 * sig[:, 0, :, :].unsqueeze(1) + attn2 * sig[:, 1, :, :].unsqueeze(1)
                attn = self.conv(attn)
                laterals[i - 1] = laterals[i - 1] + up_result + attn_in * attn
                # laterals[i - 1] = laterals[i - 1] + self.conv_fc(torch.cat([down_result, up_result], dim=1))
                # laterals[i - 1] = laterals[i - 1] + laterals[i - 1] * self.eca(laterals[i - 1])
            else:
                laterals[i - 1] = laterals[i - 1] + up_result
        # --------------------------------------------------------------------------------------------------------------
        # used_backbone_levels = len(laterals)
        # for i in range(used_backbone_levels - 1, 0, -1):
        #     prev_shape = laterals[i - 1].shape[2:]
        #     up_result = F.interpolate(laterals[i], size=prev_shape, **self.upsample_cfg)
        #     if i > 1:
        #         down_result = self.max_pool(laterals[i - 2])
        #         laterals[i - 1] = laterals[i - 1] + self.conv_fc(torch.cat([down_result, up_result], dim=1))
        #         # laterals[i - 1] = laterals[i - 1] + laterals[i - 1] * self.eca(laterals[i - 1])
        #     else:
        #         laterals[i - 1] = laterals[i - 1] + self.d_conv(laterals[i - 1] + up_result)
        # --------------------------------------------------------------------------------------------------------------
        # used_backbone_levels = len(laterals)
        # for i in range(used_backbone_levels - 1, 0, -1):
        #     prev_shape = laterals[i - 1].shape[2:]
        #     attn = self.conv_fc(self.conv_fc(laterals[i]) + self.d_convs[i - 1](laterals[i]))
        #     up_result = F.interpolate(attn, size=prev_shape, **self.upsample_cfg)
        #     laterals[i - 1] = laterals[i - 1] + up_result
        # --------------------------------------------------------------------------------------------------------------
        # pool_list = []
        # # outs = []
        # pool_list.append(laterals[0])
        # for i in range(1, 4):
        #     pool_list.append(laterals[i] + self.maxpool(laterals[i - 1]))
        # for i in range(used_backbone_levels):
        #     ins = laterals[i] + laterals[i] * pool_list[i]
        #     attn1 = self.conv0(ins)
        #     attn2 = self.conv_spatial(attn1)
        #
        #     attn1 = self.conv1(attn1)
        #     attn2 = self.conv2(attn2)
        #
        #     attn = torch.cat([attn1, attn2], dim=1)
        #     avg_attn = torch.mean(attn, dim=1, keepdim=True)
        #     max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        #     agg = torch.cat([avg_attn, max_attn], dim=1)
        #     sig = self.conv_squeeze(agg).sigmoid()
        #     attn = attn1 * sig[:, 0, :, :].unsqueeze(1) + attn2 * sig[:, 1, :, :].unsqueeze(1)
        #     attn = self.conv(attn)
        #     # laterals[i] = laterals[i] + ins * attn   # 77.0
        #     laterals[i] = ins + ins * attn   #
        # --------------------------------------------------------------------------------------------------------------

        # self-bulid bottom-up path
        # --------------------------------------------------------------------------------------------------------------
        # for i in range(0, used_backbone_levels - 1):
        #     laterals[i + 1] = laterals[i + 1] + laterals[i + 1] * self.downsamp_modules[i](laterals[i])
        # --------------------------------------------------------------------------------------------------------------




        # build outputs
        # part 1: from original levels
        outs = [
            self.fpn_convs[i](laterals[i]) for i in range(used_backbone_levels)
        ]

        # for i in range(used_backbone_levels):
        #     outs[i] = outs[i] + outs[i] * self.add_dynamic_convs[i](outs[i])

        # --------------------------------------------------------------------------------------------------------------
        # prev_shape = outs[1].shape[2:]
        # add = self.down_samp1(outs[0])
        # add = add + outs[1]
        # add = add + F.interpolate(outs[2], size=prev_shape, **self.upsample_cfg)
        # add = add + F.interpolate(outs[3], size=prev_shape, **self.upsample_cfg)
        # attn1 = self.d_conv1(add)
        # attn2 = self.d_conv2(add)
        # attn = torch.cat([attn1, attn2], dim=1)
        # avg_attn = torch.mean(attn, dim=1, keepdim=True)
        # max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        # agg = torch.cat([avg_attn, max_attn], dim=1)
        # sig = self.conv_squeeze(agg).sigmoid()
        # attn = attn1 * sig[:, 0, :, :].unsqueeze(1) + attn2 * sig[:, 1, :, :].unsqueeze(1)
        # attn = add + add * attn
        # prev_shape = outs[0].shape[2:]
        # outs[0] = outs[0] + F.interpolate(attn, size=prev_shape, **self.upsample_cfg)
        # outs[1] = outs[1] + attn
        # outs[2] = self.down_samp1(outs[1]) + self.down_samp1(attn)
        # outs[3] = self.down_samp1(outs[2]) + self.down_samp2(attn)
        # for i in range(len(outs)):
        #     outs[i] = self.norm_act(self.fc_norm(self.conv_fc(outs[i])))

        # derive_sig = self.my_eca(outs[0])
        # derive_attn = self.derive_conv(laterals[-1])
        # derive_out = derive_attn + derive_attn * derive_sig
        # --------------------------------------------------------------------------------------------------------------
        # for i in range(2):
        #     outs[3] = outs[3] + outs[3] * self.shallow_deeps[i](outs[i])
        # --------------------------------------------------------------------------------------------------------------
        p5 = self.eca(outs[3])
        attn = self.shallow_deeps[0](outs[0]) + self.shallow_deeps[1](outs[1]) + self.shallow_deeps[2](outs[2])
        # attn = self.shallow_deeps[0](outs[0]) + self.shallow_deeps[1](outs[1])
        outs[3] = outs[3] + p5 * attn
        # --------------------------------------------------------------------------------------------------------------




        # part 2: add extra levels
        if self.num_outs > len(outs):
            # use max pool to get more levels on top of outputs
            # (e.g., Faster R-CNN, Mask R-CNN)
            if not self.add_extra_convs:
                for i in range(self.num_outs - used_backbone_levels):
                    outs.append(F.max_pool2d(outs[-1], 1, stride=2))      # 原始
                    # outs.append(F.max_pool2d(outs[-1] + outs[-1] * derive_sig, 1, stride=2))
            # add conv layers on top of original feature maps (RetinaNet)
            else:
                if self.add_extra_convs == 'on_input':
                    extra_source = inputs[self.backbone_end_level - 1]
                elif self.add_extra_convs == 'on_lateral':
                    extra_source = laterals[-1]
                elif self.add_extra_convs == 'on_output':
                    extra_source = outs[-1]
                else:
                    raise NotImplementedError
                outs.append(self.fpn_convs[used_backbone_levels](extra_source))
                for i in range(used_backbone_levels + 1, self.num_outs):
                    if self.relu_before_extra_convs:
                        outs.append(self.fpn_convs[i](F.relu(outs[-1])))
                    else:
                        outs.append(self.fpn_convs[i](outs[-1]))
        return tuple(outs)
