# Copyright (c) OpenMMLab. All rights reserved.
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import ConvModule
from mmcv.runner import BaseModule, auto_fp16

from mmdet.models.builder import NECKS
# from ..backbones.atts_blocks.self_mlp import mlp_v6_3   # 不用 没效果 ，只用在backbone
# -------------------------------------------
from ..backbones.atts_blocks.Neck_block import UpSampEnhance_v1
from ..backbones.atts_blocks.Neck_block import DownSampEnhance_v1
from ..backbones.atts_blocks.Neck_block import DownSampEnhance_v2
from ..backbones.atts_blocks.Neck_block import DownSampEnhance_v3
from ..backbones.atts_blocks.Neck_block import PositionAtt
from ..backbones.atts_blocks.Neck_block import CatAtt
from ..backbones.atts_blocks.Neck_block import _ASPP
from ..backbones.atts_blocks.Neck_block import DynamicPoolingV1
from ..backbones.atts_blocks.Self_Attention import Self_Attn
from ..backbones.atts_blocks.se import SEBlock  # IFWM用

# -------------------------------------------
from ..backbones.atts_blocks.eca import eca_layer
# -------------------------------------------

@NECKS.register_module()
class MyFPN(BaseModule):
    r"""Feature Pyramid Network.

    This is an implementation of paper `Feature Pyramid Networks for Object
    Detection <https://arxiv.org/abs/1612.03144>`_.

    Args:
        in_channels (list[int]): Number of input channels per scale.
        out_channels (int): Number of output channels (used at each scale).
        num_outs (int): Number of output scales.
        start_level (int): Index of the start input backbone level used to
            build the feature pyramid. Default: 0.
        end_level (int): Index of the end input backbone level (exclusive) to
            build the feature pyramid. Default: -1, which means the last level.
        add_extra_convs (bool | str): If bool, it decides whether to add conv
            layers on top of the original feature maps. Default to False.
            If True, it is equivalent to `add_extra_convs='on_input'`.
            If str, it specifies the source feature map of the extra convs.
            Only the following options are allowed

            - 'on_input': Last feat map of neck inputs (i.e. backbone feature).
            - 'on_lateral': Last feature map after lateral convs.
            - 'on_output': The last output feature map after fpn convs.
        relu_before_extra_convs (bool): Whether to apply relu before the extra
            conv. Default: False.
        no_norm_on_lateral (bool): Whether to apply norm on lateral.
            Default: False.
        conv_cfg (dict): Config dict for convolution layer. Default: None.
        norm_cfg (dict): Config dict for normalization layer. Default: None.
        act_cfg (dict): Config dict for activation layer in ConvModule.
            Default: None.
        upsample_cfg (dict): Config dict for interpolate layer.
            Default: dict(mode='nearest').
        init_cfg (dict or list[dict], optional): Initialization config dict.

    Example:
        >>> import torch
        >>> in_channels = [2, 3, 5, 7]
        >>> scales = [340, 170, 84, 43]
        >>> inputs = [torch.rand(1, c, s, s)
        ...           for c, s in zip(in_channels, scales)]
        >>> self = FPN123(in_channels, 11, len(in_channels)).eval()
        >>> outputs = self.forward(inputs)
        >>> for i in range(len(outputs)):
        ...     print(f'outputs[{i}].shape = {outputs[i].shape}')
        outputs[0].shape = torch.Size([1, 11, 340, 340])
        outputs[1].shape = torch.Size([1, 11, 170, 170])
        outputs[2].shape = torch.Size([1, 11, 84, 84])
        outputs[3].shape = torch.Size([1, 11, 43, 43])
    """

    def __init__(self,
                 in_channels,  # 输入通道数[]
                 out_channels, # 输出通道数，一个统一数字
                 num_outs,  # 输出层数， 默认一般为in_channels数
                 start_level=0,
                 end_level=-1,
                 add_extra_convs=False,  # 是否添加额外的卷积
                 relu_before_extra_convs=False,   # 是否在额外添加的卷积前面添加relu
                 no_norm_on_lateral=False,  # 在lateral上使用norm不
                 conv_cfg=None,     # 卷积配置
                 norm_cfg=None,     # norm配置
                 act_cfg=None,      # 激活函数配置
                 upsample_cfg=dict(mode='nearest'),  # 上采样算法配置
                 init_cfg=dict(
                     type='Xavier', layer='Conv2d', distribution='uniform')):    # 参数初始化配置
        super(MyFPN, self).__init__(init_cfg)
        assert isinstance(in_channels, list)
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_ins = len(in_channels)
        self.num_outs = num_outs
        self.relu_before_extra_convs = relu_before_extra_convs
        self.no_norm_on_lateral = no_norm_on_lateral
        self.fp16_enabled = False   # 默认不使用fp16
        self.upsample_cfg = upsample_cfg.copy()

        if end_level == -1 or end_level == self.num_ins - 1:
            self.backbone_end_level = self.num_ins   # 设置backbone的结束层为4
            assert num_outs >= self.num_ins - start_level    # 输出层数必须大于等于:  输入- 开始层数
        else:
            # if end_level is not the last level, no extra level is allowed
            self.backbone_end_level = end_level + 1
            assert end_level < self.num_ins
            assert num_outs == end_level - start_level + 1
        self.start_level = start_level
        self.end_level = end_level
        self.add_extra_convs = add_extra_convs
        assert isinstance(add_extra_convs, (str, bool))    # 设置额外卷积的配置要求  看不太懂  要么boolean  要么 str 三个选项
        if isinstance(add_extra_convs, str):  # 如果是str
            # Extra_convs_source choices: 'on_input', 'on_lateral', 'on_output'
            assert add_extra_convs in ('on_input', 'on_lateral', 'on_output')  # 必须在这三个里面的值
        elif add_extra_convs:  # True   # 如果是布尔值
            self.add_extra_convs = 'on_input'

        self.lateral_convs = nn.ModuleList()   # 设置 1X1 卷积 统一改变通道数
        self.fpn_convs = nn.ModuleList()   # 设置最后连接完的fpn卷积

        for i in range(self.start_level, self.backbone_end_level):   # 0 1 2 3
            l_conv = ConvModule(
                in_channels[i],
                out_channels,
                1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg if not self.no_norm_on_lateral else None,
                #  如果如果self.no_norm_on_lateral为false 则有norm  true 则无norm
                act_cfg=act_cfg,
                inplace=False)
            fpn_conv = ConvModule(
                out_channels,
                out_channels,
                3,
                padding=1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg,              # 一律使用norm
                act_cfg=act_cfg,
                inplace=False)

            self.lateral_convs.append(l_conv)   # 全部添加到lateral_convs
            self.fpn_convs.append(fpn_conv)     # 全部添加到fpn_convs

        # add extra conv layers (e.g., RetinaNet)
        extra_levels = num_outs - self.backbone_end_level + self.start_level    # 计算额外输出的层数 1
        if self.add_extra_convs and extra_levels >= 1:                          # 同时有额外的卷积和额外的层
            for i in range(extra_levels):
                if i == 0 and self.add_extra_convs == 'on_input':
                    in_channels = self.in_channels[self.backbone_end_level - 1]  # 如果是第一个额外层， 输入channel为最后一个in_channel
                else:
                    in_channels = out_channels      # 否则一律为out_channel
                extra_fpn_conv = ConvModule(        # 设置额外的卷积 就是下采样卷积
                    in_channels,
                    out_channels,
                    3,
                    stride=2,
                    padding=1,
                    conv_cfg=conv_cfg,
                    norm_cfg=norm_cfg,
                    act_cfg=act_cfg,
                    inplace=False)
                self.fpn_convs.append(extra_fpn_conv)   # 添加到fpn_convs中
        # add extra bottom up pathway
        self.downsample_convs = nn.ModuleList()
        self.pafpn_convs = nn.ModuleList()
        # for i in range(self.start_level + 1, self.backbone_end_level):   # 原始

        # ------
        # ------
        # ---------------------------------------以下为DownS_v1、DownS_v2、DownS_v3-------------------------------
        # for i in (7, 5, 3):
        # for i in (9, 7, 5):
        # for i in (5, 3, 1):
        # for i in ((9, 7), (7, 5), (5, 3)):
        for i in ((7, 5), (5, 3), (3, 1)):
            d_conv = ConvModule(
                out_channels,
                out_channels,
                3,
                stride=2,
                padding=1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
                inplace=False)

            # ------
            # ------
            # d_conv = DownSampEnhance_v1(256, i)                   # DownS_v1
            # d_conv = DownSampEnhance_v2(256, i[0], i[1])          # DownS_v2
            # d_conv = DownSampEnhance_v3(256)                      # DownS_v3
            pafpn_conv = ConvModule(
                out_channels,
                out_channels,
                3,
                padding=1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
                inplace=False)
            self.downsample_convs.append(d_conv)
            self.pafpn_convs.append(pafpn_conv)

        # ------
        # ------
        # -------------------------------------------------------------laterals_add_conv_start--------------------------
        # self.add_conv = nn.Conv2d(out_channels, out_channels, 3, padding=3, dilation=3)
        # -----------------或者---------------------
        # self.add_convs = nn.ModuleList()
        # for i in [5, 3, 1]:
        #     dl_conv = nn.Conv2d(out_channels, out_channels, 3, padding=i, dilation=i)
        #     self.add_convs.append(dl_conv)
        # -------------------------------------------------------------laterals_add_conv_end----------------------------

        # self.NeckBlock = UpSampEnhance(256)                                        # UpS_v1
        # --------------------------------------
        # self.position_att = PositionAtt(256)                                       # PositionAtt (reduce / no-reduce)
        # --------------------------------------
        # self.cat_att = CatAtt(256)                                                 # CatAtt
        # --------------------------------------
        # self.aspp = _ASPP(256, 256, [6, 12, 18])                                   # ASPP
        # --------------------------------------
        # self.conv_squeeze = nn.Conv2d(2, 2, 7, padding=3)                         # C_split2_att && split_att
        # self.conv_squeeze = nn.Conv2d(2, 3, 7, padding=3)                         # C_split3_att
        # --------------------------------------
        # self.self_att = Self_Attn(256, 'relu')                                    # official_SA
        # --------------------------------------
        # self.dp1 = DynamicPoolingV1(256)                                          # DP1
        # --------------------------------------
        # -------------------------------------------------------------IFEM_start---------------------------------------
        # self.conv_reduces = nn.ModuleList()
        # self.conv_ds = nn.ModuleList()
        # # self.conv_squeezes = nn.ModuleList()
        # # self.ses = nn.ModuleList()    # 不使用se
        # self.norms = nn.ModuleList()
        # for i in ((512, 7), (1024, 5), (2048, 3)):
        #     in_c = i[0]
        #     out_c = i[0] // 2
        #     reduce_conv = nn.Conv2d(in_c, out_c, 1)
        #     d_conv = nn.Conv2d(out_c, out_c, 3, padding=i[1], dilation=i[1])
        #     # conv_squeeze = nn.Conv2d(2, 1, 7, padding=3)
        #     # se = SEBlock(out_c)    # 不使用se
        #     norm = nn.BatchNorm2d(out_c)
        #     self.conv_reduces.append(reduce_conv)
        #     self.conv_ds.append(d_conv)
        #     # self.conv_squeezes.append(conv_squeeze)
        #     # self.ses.append(se)    # 不使用se
        #     self.norms.append(norm)
        # self.act_layer = nn.ReLU(inplace=True)
        # -------------------------------------------------------------IFEM_end-----------------------------------------

        self.eca = eca_layer(256)                                    # FPN_conv_All  &&  FPN_PAFPN_conv_All  (eca)

        # --------------------------------------
        # self.conv_connect = nn.Conv2d(256, 256, 1)                 # Du_shortcut
        # --------------------------------------

        # -------------------------------------------------------------Ups_v2_start-------------------------------------
        # self.large_conv = nn.Conv2d(256, 256, 3, padding=7, dilation=7)
        # self.conv_fc = nn.Conv2d(256, 256, 1)
        # -------------------------------------------------------------Ups_v2_end---------------------------------------

        # self.derive_down = DownSampEnhance_v1(256, 3)                # derive_16_DownS_v1-3
        # --------------------------------------



    @auto_fp16()
    def forward(self, inputs):
        """Forward function."""
        assert len(inputs) == len(self.in_channels)  # 判断输入是否满足条件

        # ------
        # ------
        # -------------------------------------------------------------C_split2_att_start-------------------------------
        # sigs = []
        # for _in in inputs:
        #     avg_attn = torch.mean(_in, dim=1, keepdim=True)
        #     max_attn, _ = torch.max(_in, dim=1, keepdim=True)
        #     agg = torch.cat([avg_attn, max_attn], dim=1)
        #     sig = self.conv_squeeze(agg).sigmoid()
        #     sigs.append(sig)
        # -------------------------------------------------------------C_split2_att_end---------------------------------

        # -------------------------------------------------------------IFEM_start---------------------------------------
        # !!!!  要调整学习率小一点 ，否则会过拟合 !!!!
        # inputs = list(inputs)   # 转换为list，否则没有办法做修改
        # used_input_levels = len(inputs)
        # for i in range(used_input_levels - 1, 0, -1):
        #     prev_shape = inputs[i - 1].shape[2:]
        #     out = F.interpolate(self.conv_reduces[i - 1](inputs[i]), size=prev_shape, **self.upsample_cfg)  # 上采样
        #     out = self.conv_ds[i - 1](out)
        # ----------------------------------------------SA_start--------------------------------
        #     avg_attn = torch.mean(out, dim=1, keepdim=True)
        #     max_attn, _ = torch.max(out, dim=1, keepdim=True)
        #     agg = torch.cat([avg_attn, max_attn], dim=1)
        #     sig1 = self.conv_squeezes[i - 1](agg).sigmoid()

        #     --------------------SA_方式选择_start-----------------------
        #     out = self.ses[i - 1](out) * sig1 + out                # Full_o1
        #     out = self.ses[i - 1](out) * sig1 * out                # Full_o2  (o2效果好 o3最差)  默认使用o2
        #     out = self.ses[i - 1](out) * sig1 * out + out          # Full_o3
        #     --------------------SA_方式选择_end-----------------------
        # ----------------------------------------------SA_end----------------------------------

        # ----------------------------------------------se_start--------------------------------
        #     out = self.ses[i - 1](out)   # se不使用内部方式
        # ----------------------------------------------se_end----------------------------------

        # ----------------------------------------------输出方式选择_start-------------------------
        #     out = out * sig1                                       # in_o1
        #     out = out + out * sig1                                 # in_o2
        #     out = out * out * sig1                                 # in_o3
        # ----------------------------------------------输出方式选择_end---------------------------

        # ----------------------------------------------更新inputs方式选择_start-------------------
        #     inputs[i - 1] = inputs[i - 1] * self.act_layer(self.norms[i - 1](out))                  # o1
            # inputs[i - 1] = inputs[i - 1] + inputs[i - 1] * self.act_layer(self.norms[i - 1](out))  # o2
        #     inputs[i - 1] = inputs[i - 1] + self.act_layer(self.norms[i - 1](inputs[i - 1] * out))  # o3
        #     inputs[i - 1] = self.act_layer(self.norms[i - 1](inputs[i - 1] * out))                  # o4
        # ----------------------------------------------更新inputs方式选择_end---------------------

        # ----------------------------------------------记录_start-------------------------------
        #     d_conv_out-o1                 67.0
        #     d_conv_out-o2                 68.1
        #     d_conv_out-o3                 65.8
        #     d_conv_out-o4                 65.7
        #     d_conv_out+se-o2              66.8
        #     d_conv_out+SA-in_o1-o1
        #     d_conv_out+SA-in_o2-o1
        #     d_conv_out+SA-in_o3-o1
        #     d_conv_out+SA-in_o1-o2        64.6
        #     d_conv_out+SA-in_o2-o2        65.4
        #     d_conv_out+SA-in_o3-o2        66.1
        #     Full_o2-o2
        # ----------------------------------------------记录_end---------------------------------
        # -------------------------------------------------------------IFEM_end-----------------------------------------

        # build laterals
        laterals = [lateral_conv(inputs[i + self.start_level]) for i, lateral_conv in enumerate(self.lateral_convs)]  # 原始

        # ------
        # ------
        # ---------------------------------------------C_split2_att_start-----------------------------------------------
        # laterals = [lateral_conv(inputs[i + self.start_level] +
        #                          inputs[i + self.start_level] * sigs[i][:,0,:,:].unsqueeze(1))
        #             for i, lateral_conv in enumerate(self.lateral_convs)]
        # ----------------------------------------------C_split2_att_end------------------------------------------------

        # same_in = laterals.copy()                                                                # 2_shortcut

        # ----------------------------------------------laterals_add_conv_start-----------------------------------------
        #  !!! 需要打开原始
        # add_laterals = [add_conv(laterals[i+1]) for i, add_conv in enumerate(self.add_convs)]
        # add_laterals.insert(0, 'hhhh')  # 占位
        # ----------------------------------------------laterals_add_conv_end-------------------------------------------

        # up_results = []                                                                          # 保存上采样结果

        # --------------------------------------------

        # build top-down path
        # 倒序 改变后三个laterals[1], laterals[2], laterals[3]
        used_backbone_levels = len(laterals)  # 设置可以用的 backbone层数 4
        for i in range(used_backbone_levels - 1, 0, -1):    # 倒数着迭代， 3, 2, 1
            # In some cases, fixing `scale factor` (e.g. 2) is preferred, but
            #  it cannot co-exist with `size` in `F.interpolate`.
            if 'scale_factor' in self.upsample_cfg:  # 要么用scale_factor
                # fix runtime error of "+=" inplace operation in PyTorch 1.10
                laterals[i - 1] = laterals[i - 1] + F.interpolate(
                    laterals[i], **self.upsample_cfg)
            else:  # 要么用 size  两者不能同时使用   默认是使用这个
                prev_shape = laterals[i - 1].shape[2:]
                # --------------------------------------原始版本_start----------------------------------------------------
                laterals[i - 1] = laterals[i - 1] + F.interpolate(laterals[i], size=prev_shape, **self.upsample_cfg)
                # --------------------------------------原始版本_end------------------------------------------------------

                # ------
                # ------
                # --------------------------------------selfwrite_att_start---------------------------------------------
                # up_result = F.interpolate(laterals[i], size=prev_shape, **self.upsample_cfg)
                # up_result = up_result * up_result.sigmoid()
                # laterals[i - 1] = laterals[i - 1] + up_result
                # --------------------------------------selfwrite_att_end-----------------------------------------------

                # --------------------------------------Official_SA_start-----------------------------------------------
                # laterals[i - 1] = laterals[i - 1] + F.interpolate(
                #     self.self_att(laterals[i]), size=prev_shape, **self.upsample_cfg)
                # --------------------------------------Official_SA_end-------------------------------------------------

                # --------------------------------------channel_reduce_att_start----------------------------------------
                # up_result = F.interpolate(laterals[i], size=prev_shape, **self.upsample_cfg)
                # avg_attn = torch.mean(up_result, dim=1, keepdim=True)
                # max_attn, _ = torch.max(up_result, dim=1, keepdim=True)
                # agg = torch.cat([avg_attn, max_attn], dim=1)
                # sig = self.conv_squeeze(agg).sigmoid()
                # laterals[i - 1] = laterals[i - 1] + laterals[i - 1] * sig[:, 0, :, :].unsqueeze(1) + \
                #     up_result + up_result * sig[:, 1, :, :].unsqueeze(1)
                # --------------------------------------channel_reduce_att_end------------------------------------------

                # --------------------------------------保存上采样结果_start-----------------------------------------------
                # up_result = F.interpolate(laterals[i], size=prev_shape, **self.upsample_cfg)
                # up_results.insert(0, up_result)
                # laterals[i - 1] = laterals[i - 1] + up_result
                # --------------------------------------保存上采样结果_end-------------------------------------------------

                # --------------------------------------laterals_add_conv_start-----------------------------------------
                # laterals[i - 1] = laterals[i - 1] + F.interpolate(
                #     laterals[i], size=prev_shape, **self.upsample_cfg) + F.interpolate(
                #     add_laterals[i], size=prev_shape, **self.upsample_cfg)
                # --------------------------------------laterals_add_conv_end-------------------------------------------

                # --------------------------------------UpS_v1_start----------------------------------------------------
                # laterals[i - 1] = laterals[i - 1] + F.interpolate(
                #     laterals[i], size=prev_shape, **self.upsample_cfg) + F.interpolate(
                #     self.NeckBlock(laterals[i]), size=prev_shape, **self.upsample_cfg)
                # --------------------------------------UpS_v1_end------------------------------------------------------

                # --------------------------------------P4+mlp_v6.3+shortcut_start--------------------------------------
                # if i == 2:
                #     laterals[i - 1] = laterals[i - 1] + F.interpolate(
                #         laterals[i], size=prev_shape, **self.upsample_cfg) + F.interpolate(
                #         self.mlp3(laterals[i]), size=prev_shape, **self.upsample_cfg)
                # else:
                #     laterals[i - 1] = laterals[i - 1] + F.interpolate(
                #         laterals[i], size=prev_shape, **self.upsample_cfg)
                # --------------------------------------P4+mlp_v6.3+shortcut_end----------------------------------------

                # --------------------------------------Du_shortcut_start-----------------------------------------------
                # up_result = F.interpolate(laterals[i], size=prev_shape, **self.upsample_cfg)
                # attn = self.conv_connect(up_result)
                # laterals[i - 1] = laterals[i - 1] + up_result + attn
                # --------------------------------------Du_shortcut_end-------------------------------------------------

                # --------------------------------------Ups_v2_start----------------------------------------------------
                # b1 = F.interpolate(laterals[i], size=prev_shape, **self.upsample_cfg)
                # b2 = F.interpolate(self.large_conv(laterals[i]), size=prev_shape, **self.upsample_cfg)
                # attn = self.conv_fc(b1 + b2)
                # laterals[i - 1] = laterals[i - 1] + attn
                # --------------------------------------Ups_v2_end------------------------------------------------------

        # ------
        # ------
        # ----------------------------------------------------
        # derive_attn = self.derive_down(laterals[3])                                 # derive_16_DownS_v1-3的attn
        # ----------------------------------------------------



        # ----------------------------------------------使用PAFPN的时候不打开----------------------------------------------
        # build outputs   FPN原始的
        # part 1: from original levels
        # outs = [self.fpn_convs[i](laterals[i]) for i in range(used_backbone_levels)]
        # --------------------------------------------------------------------------------------------------------------

        inter_outs = [self.fpn_convs[i](laterals[i]) for i in range(used_backbone_levels)]                 # PAFPN原始

        # ------
        # ------
        # ----------------------------------------------
        # inter_outs = [self.fpn_convs[i](laterals[i]) + same_in[i] for i in range(used_backbone_levels)]  # 2_shortcut

        # ----------------------------------------------C_split2_att_start----------------------------------------------
        # inter_outs = [self.fpn_convs[i](laterals[i] + laterals[i] * sigs[i][:, 1, :, :].unsqueeze(1))
        # for i in range(used_backbone_levels)]
        # ----------------------------------------------C_split2_att_end------------------------------------------------

        # ----------------------------------------------Dp_connection_start---------------------------------------------
        # inter_outs = [self.fpn_convs[i](laterals[i]) + laterals[i]
        # for i in range(used_backbone_levels)]  #
        # ----------------------------------------------Dp_connection_end-----------------------------------------------

        # ----------------------------------------------CatAtt_start----------------------------------------------------
        # !!! 需要打开PAFPN原始
        # for i in range(used_backbone_levels-1):
        #         inter_outs[i] = inter_outs[i] + inter_outs[i] * self.cat_att(up_results[i], laterals[i])
        # ----------------------------------------------CatAtt_end------------------------------------------------------

        # ----------------------------------------------FPN_conv_All && PAFPN_conv_All_start----------------------------
        for i in range(used_backbone_levels):
            inter_outs[i] = inter_outs[i] + inter_outs[i] * self.eca(inter_outs[i])
        # ----------------------------------------------FPN_conv_All && PAFPN_conv_All_end------------------------------

        # tempPosition = self.position_att(laterals[0])                                                 # PositionAtt
        # ----------------------------------------
        # shortcut_2 = inter_outs.copy()                                                                # 2_shortcut
        # ----------------------------------------



        # part 2: add bottom-up path
        for i in range(0, used_backbone_levels - 1):
            inter_outs[i + 1] = inter_outs[i + 1] + self.downsample_convs[i](inter_outs[i])              # 原始

            # ------
            # ------
            # --------------------------------------------------
            # inter_outs[i + 1] = self.dp1(inter_outs[i + 1]) + self.downsample_convs[i](inter_outs[i])  # DP1

            # ------------------------------------------C_split3_att_start----------------------------------------------
            # inter_outs[i + 1] = inter_outs[i + 1] + \
            #                     inter_outs[i + 1] * sigs[i + 1][:,2,:,:].unsqueeze(1) + \
            #                     self.downsample_convs[i](inter_outs[i])
            # ------------------------------------------C_split3_att_end------------------------------------------------

            # inter_outs[i + 1] = self.aspp(inter_outs[i + 1]) + self.downsample_convs[i](inter_outs[i])  # ASPP

            # ------------------------------------------PositionAtt_start-----------------------------------------------
            # ------------------PositionAtt_原始---------------------
            # inter_outs[i + 1] = inter_outs[i + 1] + self.downsample_convs[i](inter_outs[i]) + tempPosition[i]

            # ------------------PositionAtt + CP连接-----------------
            # ! 效果下降
            # inter_outs[i + 1] = inter_outs[i + 1] +
            # self.downsample_convs[i](inter_outs[i]) + tempPosition[i] + same_in[i + 1]

            # ------------------------------------------PositionAtt_end-------------------------------------------------

            # ------------------------------------------split_att_start----------------------------------------
            # avg_attn = torch.mean(inter_outs[i+1], dim=1, keepdim=True)
            # max_attn, _ = torch.max(inter_outs[i+1], dim=1, keepdim=True)
            # agg = torch.cat([avg_attn, max_attn], dim=1)
            # sig = self.conv_squeeze(agg).sigmoid()
            # down_result = self.downsample_convs[i](inter_outs[i])
            # inter_outs[i + 1] = inter_outs[i + 1] + inter_outs[i + 1] * sig[:, 0, :, :].unsqueeze(1) + down_result + \
            #     down_result * sig[:, 1, :, :].unsqueeze(1)
            # ------------------------------------------split_att_end------------------------------------------

            # ------------------------------------------Du_shortcut_start-----------------------------------------------
            # down = self.downsample_convs[i](inter_outs[i])
            # attn = self.conv_connect(down)
            # inter_outs[i + 1] = inter_outs[i + 1] + down + attn
            # ------------------------------------------Du_shortcut_end-------------------------------------------------



        outs = []
        outs.append(inter_outs[0])                                              # 初始

        # ------
        # ------
        # outs.append(inter_outs[0])                                              # 2_shortcut
        # outs.append(self.aspp(inter_outs[0]))                                   # ASPP  是否在第一层自底向上添加ASPP？
        # outs.append(inter_outs[0] + same_in[0])                                 # CP连接
        # outs.append(inter_outs[0] * sigs[0][:,2,:,:].unsqueeze(1))              # C_split3_att

        # 原始pafpn的outs
        outs.extend([self.pafpn_convs[i - 1](inter_outs[i]) for i in range(1, used_backbone_levels)])

        # ------
        # ------
        # ----------------------------------------------2_shortcut_start------------------------------------------------
        # outs.extend([self.pafpn_convs[i - 1](inter_outs[i]) + shortcut_2[i] for i in range(1, used_backbone_levels)])
        # ----------------------------------------------2_shortcut_end--------------------------------------------------

        # ----------------------------------------------Dp_connection_start---------------------------------------------
        # outs.extend([self.pafpn_convs[i - 1](inter_outs[i]) + inter_outs[i] for i in range(1, used_backbone_levels)])
        # ----------------------------------------------Dp_connection_end-----------------------------------------------

        # ----------------------------------------------FPN_PAFPN_conv_All_start----------------------------------------
        # for i in range(used_backbone_levels):
        #     outs[i] = outs[i] + outs[i] * self.eca(outs[i])
        # ----------------------------------------------FPN_PAFPN_conv_All_end------------------------------------------


        # part 3: add extra levels
        if self.num_outs > len(outs):
            # use max pool to get more levels on top of outputs
            # (e.g., Faster R-CNN, Mask R-CNN)
            if not self.add_extra_convs:  # 如果不添加额外的卷积的话  直接使用p5进行maxpool进行下采样
                #  默认使用的是这个
                for i in range(self.num_outs - used_backbone_levels):   # 迭代得到多余层的输出
                    outs.append(F.max_pool2d(outs[-1], 1, stride=2))                            # 原始

                    # ------
                    # ------
                    # --------------------------------------------------------------------------------------------------
                    # outs.append(F.max_pool2d(outs[-1], 1, stride=2) + derive_attn)              # derive_16_DownS_v1-3
                    # -----------------------------------------

            # add conv layers on top of original feature maps (RetinaNet)
            else:     # 如果有额外的卷积的话
                if self.add_extra_convs == 'on_input':   #  如果self.add_extra_convs是on_input, extra的输入是inputs[3]
                    extra_source = inputs[self.backbone_end_level - 1]
                elif self.add_extra_convs == 'on_lateral':   #  如果self.add_extra_convs是on_lateral,extra的输入是laterals[3]
                    extra_source = laterals[-1]
                elif self.add_extra_convs == 'on_output':   #  如果self.add_extra_convs是on_output,extra的输入是outs[3]
                    extra_source = outs[-1]
                else:
                    raise NotImplementedError    # 什么都没有进入 报错
                outs.append(self.fpn_convs[used_backbone_levels](extra_source))   # 添加fpn_convs[4](输入)
                # 设置剩下的多余层的输出
                for i in range(used_backbone_levels + 1, self.num_outs):     # 从 5 开始， 到输出的次数
                    if self.relu_before_extra_convs:    #  如果在额外卷积前面使用relu  先relu再卷积出去
                        outs.append(self.fpn_convs[i](F.relu(outs[-1])))
                    else:  # 不使用  直接直接 卷积出去
                        outs.append(self.fpn_convs[i](outs[-1]))
        return tuple(outs)
