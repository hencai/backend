import torch
import torch.nn as nn
from .eca import eca_layer
from .se import SEBlock
import torch.nn.functional as F
from torch.nn import SyncBatchNorm
from ..atts_blocks.self_mlp import DepthwiseSeparableConv

_BATCH_NORM = SyncBatchNorm


class UpSampEnhance_v1(nn.Module):   # 四分支，dilated maxpool avgpool residual connection  v8.0
    def __init__(self, dim):
        super().__init__()
        self.branch1 = nn.Conv2d(dim, dim, 3, padding=5, dilation=5)
        self.branch2 = nn.Conv2d(dim, dim, 5, padding=14, dilation=7)
        self.branch3 = nn.MaxPool2d(kernel_size=3, stride=1, padding=1)
        self.branch4 = nn.MaxPool2d(kernel_size=5, stride=1, padding=2)
        self.channel_squeeze = nn.Conv2d(dim * 2, 2, 1)
        self.norm = nn.LayerNorm(dim, eps=1e-6)  # 使用LN进行归一化
        self.att = eca_layer(dim)
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x):
        shortcut = x
        b1 = self.branch1(x)
        b2 = self.branch2(x)
        b3 = self.branch3(x)
        b4 = self.branch4(x)
        attn1 = b1 + b3
        attn2 = b2 + b4
        attn = torch.cat([attn1, attn2], dim=1)
        sig = self.channel_squeeze(attn).sigmoid()
        attn = attn1 * sig[:, 0, :, :].unsqueeze(1) + attn2 * sig[:, 1, :, :].unsqueeze(1)
        attn = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        attn = self.att(attn.permute(0, 3, 1, 2).contiguous())
        return shortcut * self.act_layer(attn)  # 6.0 这种方式效果好点


class DownSampEnhance_v4(nn.Module):   # SSFPN的改进--浅层倒数两层指导最后一层模型学习
    def __init__(self, pool_s):
        super().__init__()
        self.norm1 = nn.BatchNorm2d(256)
        self.max_pool = nn.MaxPool2d(9, padding=4, stride=pool_s)
        self.pool_conv = nn.Conv2d(256, 256, 7, padding=3, stride=pool_s, groups=256)
        self.d_conv = nn.Conv2d(256, 256, 7, dilation=3, padding=9, groups=256)
        self.conv_fc = nn.Conv2d(256, 256, 1)
        self.norm2 = nn.BatchNorm2d(256)
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x):
        attn_in = self.norm1(x)
        attn = self.act_layer(self.norm2(self.conv_fc(self.d_conv(self.max_pool(attn_in) + self.pool_conv(attn_in)))))
        return attn


class DownSampEnhance_v3(nn.Module):   # SSFPN的改进自下向上浅层指导深层网络收敛优化
    def __init__(self, dim, dilation1):
        super().__init__()
        # channel_in = dim // 2
        self.norm1 = nn.BatchNorm2d(dim)
        self.d_conv1 = DepthwiseSeparableConv(dim, dim, 3, dilation=dilation1)
        self.d_conv2 = DepthwiseSeparableConv(dim, dim, 5, dilation=dilation1)
        self.max_pool = nn.MaxPool2d(3, padding=1, stride=2)
        self.avg_pool = nn.AvgPool2d(5, padding=2, stride=2)
        self.norm2 = nn.BatchNorm2d(dim)
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x):
        # shortcut = x
        attn_in = self.norm1(x)
        # attn = self.act_layer(self.norm2(self.max_pool(self.d_conv1(attn_in))) + self.d_conv2(self.avg_pool(attn_in)))
        # 以上发现norm错误  改进尝试结果
        attn = self.act_layer(self.norm2(self.max_pool(self.d_conv1(attn_in)) + self.d_conv2(self.avg_pool(attn_in))))
        return attn


class DownSampEnhance_v3_pre(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.branch1 = nn.Conv2d(dim, dim, 3, stride=2, padding=1, dilation=1)
        self.branch2 = nn.Conv2d(dim, dim, 3, stride=2, padding=7, dilation=7)
        self.branch3 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.norm = nn.BatchNorm2d(dim)
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x):
        b1 = self.branch1(x)
        b2 = self.branch2(x)
        b3 = self.branch3(x)
        attn = b1 + b2 + b3
        return self.act_layer(self.norm(attn))


class DownSampEnhance_v2(nn.Module):   # 四分支，dilated maxpool avgpool residual connection  v8.0
    def __init__(self, dim, dilation1, dilation2):
        super().__init__()
        channel_in = dim // 2
        self.branch_in = nn.Conv2d(dim, channel_in, 1)
        self.branch1 = nn.Conv2d(channel_in, channel_in, 3, padding=dilation1, dilation=dilation1)
        self.branch2 = nn.Conv2d(channel_in, channel_in, 3, padding=dilation2, dilation=dilation2)
        self.conv_squeeze = nn.Conv2d(2, 2, 7, padding=3)
        self.channel_out = nn.Conv2d(channel_in, dim, 1)
        self.reduce = nn.Conv2d(dim, dim, 1, stride=2)
        self.norm = nn.LayerNorm(dim, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x):
        shortcut = x
        b_in = self.branch_in(x)
        b1 = self.branch1(b_in)
        b2 = self.branch2(b_in)
        attn = torch.cat([b1, b2], dim=1)
        avg_attn = torch.mean(attn, dim=1, keepdim=True)
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        agg = torch.cat([avg_attn, max_attn], dim=1)
        sig = self.conv_squeeze(agg).sigmoid()
        attn = b1 * sig[:, 0, :, :].unsqueeze(1) + b2 * sig[:, 1, :, :].unsqueeze(1)
        attn = self.reduce(self.channel_out(attn) * shortcut)
        attn = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        attn = self.act_layer(attn.permute(0, 3, 1, 2).contiguous())
        return attn


class DownSampEnhance_v1(nn.Module):   # 四分支，dilated maxpool avgpool residual connection  v8.0
    def __init__(self, dim, dilation):
        super().__init__()
        self.branch1 = nn.Conv2d(dim, dim, 3, stride=2, padding=dilation, dilation=dilation)
        self.branch2 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.norm = nn.LayerNorm(dim, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x):
        # shortcut = x
        b1 = self.branch1(x)
        b2 = self.branch2(x)
        b2 = self.norm(b2.permute(0, 2, 3, 1).contiguous())
        b2 = self.act_layer(b2.permute(0, 3, 1, 2).contiguous())
        return b1 + b2  # 6.0 这种方式效果好点


class DynamicPoolingV1(nn.Module):   #
    def __init__(self, dim):
        super().__init__()
        self.branch1 = nn.MaxPool2d(kernel_size=7, padding=3, stride=1)
        self.branch2 = nn.MaxPool2d(kernel_size=5, padding=2, stride=1)
        self.branch2 = nn.MaxPool2d(kernel_size=3, padding=1, stride=1)
        self.conv_squeeze = nn.Conv2d(dim * 3, 3, 7, padding=3)
        # self.conv_squeeze = nn.Conv2d(dim, 3, 7, padding=3)    #  逐元素相加版本
        self.conv_fc = nn.Conv2d(dim, dim, 1)
        self.norm = nn.BatchNorm2d(dim)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x):
        shortcut = x
        b1 = self.branch1(x)
        b2 = self.branch2(x)
        b3 = self.branch2(x)
        attn = torch.cat([b1, b2, b3], dim=1)
        # attn = torch.cat([b1, b2, b3], dim=1)  # 逐元素相加版本
        sig = self.conv_squeeze(attn).sigmoid()
        attn = b1 * sig[:, 0, :, :].unsqueeze(1) + b2 * sig[:, 1, :, :].unsqueeze(1) + b3 * sig[:, 2, :, :].unsqueeze(1)
        attn = self.conv_fc(attn) * shortcut
        return self.act_layer(self.norm(attn))


class PositionAtt(nn.Module):   #
    def __init__(self, dim):
        super().__init__()
        self.branch1 = nn.Conv2d(dim, dim, 1)
        self.branch2 = nn.Conv2d(dim, dim, 3, padding=6, dilation=6)
        self.branch3 = nn.Conv2d(dim, dim, 3, padding=12, dilation=12)
        self.branch4 = nn.Conv2d(dim, dim, 3, padding=18, dilation=18)
        self.branch5 = nn.MaxPool2d(kernel_size=5, stride=1, padding=2)
        self.reduce = nn.Conv2d(dim * 5, dim, 1)
        self.conv_squeeze = nn.Conv2d(2, 3, 7, padding=3)
        self.down = nn.Conv2d(dim, dim, 3, stride=2, padding=1)
        self.norm = nn.LayerNorm(dim, eps=1e-6)  # 使用LN进行归一化
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x):
        b1 = self.branch1(x)
        b2 = self.branch2(x)
        b3 = self.branch3(x)
        b4 = self.branch4(x)
        b5 = self.branch5(x)
        attn = torch.cat([b1, b2, b3, b4, b5], dim=1)
        attn = self.reduce(attn)  # 不压缩通道   540.xMB  压缩通道 544.xMB  但是不压缩通道 计算量要大一些， bsize要设置10 压缩是12
        avg_attn = torch.mean(attn, dim=1, keepdim=True)
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        agg = torch.cat([avg_attn, max_attn], dim=1)
        sig = self.conv_squeeze(agg).sigmoid()
        attn1 = self.down(x + x * sig[:, 0, :, :].unsqueeze(1))
        attn2 = self.down(self.down(x + x * sig[:, 1, :, :].unsqueeze(1)))
        attn3 = self.down(self.down(self.down(x + x * sig[:, 2, :, :].unsqueeze(1))))
        attn1 = self.norm(attn1.permute(0, 2, 3, 1).contiguous())
        attn1 = self.act_layer(attn1.permute(0, 3, 1, 2).contiguous())
        attn2 = self.norm(attn2.permute(0, 2, 3, 1).contiguous())
        attn2 = self.act_layer(attn2.permute(0, 3, 1, 2).contiguous())
        attn3 = self.norm(attn3.permute(0, 2, 3, 1).contiguous())
        attn3 = self.act_layer(attn3.permute(0, 3, 1, 2).contiguous())
        return [attn1, attn2, attn3]


class CatAtt(nn.Module):   #
    def __init__(self, dim):
        super().__init__()
        self.norm = nn.LayerNorm(dim * 2, eps=1e-6)  # 使用LN进行归一化
        self.channel_att = SEBlock(dim * 2)
        self.channel_reduce = nn.Conv2d(dim * 2, dim, 1)
        self.act_layer = nn.ReLU(inplace=True)

    def forward(self, x, y):
        attn = torch.cat([x, y], dim=1)
        attn = self.norm(attn.permute(0, 2, 3, 1).contiguous())
        attn = self.channel_att(attn.permute(0, 3, 1, 2).contiguous())
        sig = self.act_layer(self.channel_reduce(attn)).sigmoid()
        return sig


# ---------------ASPP---------------------
class _ImagePool(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.conv = _ConvBnReLU(in_ch, out_ch, 1, 1, 0, 1)

    def forward(self, x):
        _, _, H, W = x.shape
        h = self.pool(x)
        h = self.conv(h)
        h = F.interpolate(h, size=(H, W), mode="bilinear", align_corners=False)
        return h


class _ASPP(nn.Module):
    """
    Atrous spatial pyramid pooling with image-level feature
    """

    def __init__(self, in_ch, out_ch, rates):
        super(_ASPP, self).__init__()
        self.stages = nn.Module()
        self.stages.add_module("c0", _ConvBnReLU(in_ch, out_ch, 1, 1, 0, 1))
        for i, rate in enumerate(rates):
            self.stages.add_module(
                "c{}".format(i + 1),
                _ConvBnReLU(in_ch, out_ch, 3, 1, padding=rate, dilation=rate),
            )
        self.stages.add_module("imagepool", _ImagePool(in_ch, out_ch))
        self.channel_reduce = _ConvBnReLU(in_ch * (len(rates) + 2), out_ch, 1, 1, 0, 1)

    def forward(self, x):
        return self.channel_reduce(torch.cat([stage(x) for stage in self.stages.children()], dim=1))


class _ConvBnReLU(nn.Sequential):
    """
    Cascade of 2D convolution, batch norm, and ReLU.
    """
    BATCH_NORM = _BATCH_NORM

    def __init__(
        self, in_ch, out_ch, kernel_size, stride, padding, dilation, relu=True
    ):
        super(_ConvBnReLU, self).__init__()
        self.add_module(
            "conv",
            nn.Conv2d(
                in_ch, out_ch, kernel_size, stride, padding, dilation, bias=False
            ),
        )
        self.add_module("bn", _BATCH_NORM(out_ch, eps=1e-5, momentum=1 - 0.999))

        if relu:
            self.add_module("relu", nn.ReLU())

# ---------------ASPP---------------------

